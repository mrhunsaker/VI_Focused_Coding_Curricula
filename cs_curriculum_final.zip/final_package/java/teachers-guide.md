# Teacher's Guide: Introduction to Computer Science with Java
## For Students with Visual Impairments — Complete Instructor Edition

---

## Table of Contents

1. [Philosophy and Why Java](#1-philosophy-and-why-java)
2. [Java-Specific Accessibility Challenges](#2-java-specific-accessibility-challenges)
3. [Classroom Setup and Configuration](#3-classroom-setup-and-configuration)
4. [Spoken Java Conventions](#4-spoken-java-conventions)
5. [Unit 0–1: Setup and Foundations](#5-unit-01-setup-and-foundations)
6. [Unit 2: I/O and the Math Class](#6-unit-2-io-and-the-math-class)
7. [Unit 3: Control Flow](#7-unit-3-control-flow)
8. [Unit 4: Arrays and ArrayLists](#8-unit-4-arrays-and-arraylists)
9. [Unit 5: Strings and String Processing](#9-unit-5-strings-and-string-processing)
10. [Unit 6: Methods](#10-unit-6-methods)
11. [Unit 7: Classes and OOP](#11-unit-7-classes-and-oop)
12. [Unit 8: Files and Exception Handling](#12-unit-8-files-and-exception-handling)
13. [Unit 9: Collections, Analysis, and Testing](#13-unit-9-collections-analysis-and-testing)
14. [Units 10–11: Projects and Capstone](#14-units-1011-projects-and-capstone)
15. [Bridging from Python to Java](#15-bridging-from-python-to-java)
16. [Assessment Strategies](#16-assessment-strategies)
17. [Supporting Diverse Needs](#17-supporting-diverse-needs)
18. [Alternative and Supplementary Resources](#18-alternative-and-supplementary-resources)
19. [Quick Reference Sheets](#19-quick-reference-sheets)

---

## 1. Philosophy and Why Java

### The Case for Teaching Java to Blind Students

Java is not the easiest language for beginners, and its verbosity creates overhead that requires specific pedagogical attention. Despite this, Java has genuine advantages for visually impaired learners that are often overlooked:

**Compile-time error detection.** Java's compiler catches type errors, name errors, and structural mistakes before any code runs. A blind student does not need to search through runtime output for subtle type mismatches — the compiler announces them precisely and immediately with file name, line number, and error description.

**Strong, static typing is auditorily informative.** When IntelliSense in VS Code suggests methods, it includes the return type: "`double getBalance()` — returns a double." This type information helps a screen reader user understand what a method does without having to navigate to its definition.

**Enforced code structure.** Every Java program requires a class; every executable program requires a `main` method with a specific signature. This structure is more overhead to type but less ambiguity about how programs are organized. For a student who cannot visually scan a file for structure, predictable structural conventions reduce cognitive load.

**Exception specification.** Java's checked exceptions force programmers to declare which exceptions a method can throw. This means a screen reader user reading a method signature gets information about failure modes that Python provides only through documentation.

**Enterprise relevance.** Java remains a dominant language in enterprise software, Android development, and many backend systems. A student who learns Java learns patterns that transfer directly to professional employment.

---

## 2. Java-Specific Accessibility Challenges

### The Verbosity Problem

Java requires significantly more text than Python to accomplish the same task:

```java
// Java: Hello, World
public class HelloWorld {
    public static void main(String[] args) {
        System.out.println("Hello, World!");
    }
}
```

```python
# Python: Hello, World
print("Hello, World!")
```

For a sighted student, extra text is a visual annoyance. For a blind student, it is additional audio before they reach the meaningful code. **Mitigation strategies:**

1. **Code templates.** Provide a starter file the student copies for every new program. They modify only the method body for early lessons. This reduces the typing burden and prevents structural errors while the student is learning concepts.

2. **JShell (Java REPL).** Java includes an interactive shell since Java 9: run `jshell` in the terminal. JShell strips away class and method boilerplate. For exploration and experimentation, JShell is far more accessible than creating files:
   ```
   jshell> int x = 5;
   x ==> 5
   jshell> System.out.println(x * 2);
   10
   ```

3. **Progressive disclosure.** In early lessons, treat `public static void main(String[] args) {` as a formula, not something to understand. Students learn to recognize it by ear. Explain each word only when the concept it relates to (access modifiers, static methods, arrays) is being taught.

### Integer Division Surprises

Java's `/` operator performs integer division when both operands are integers:
- `15 / 4` = `3` (not `3.75`)
- `15.0 / 4` = `3.75`
- `(double) 15 / 4` = `3.75`

This is silent — there is no error or warning. A blind student may not catch a calculation that silently discards its decimal portion. Teach the rule explicitly: **if you want a decimal result, at least one operand must be a `double`.**

### The String Equality Trap

`==` on Strings compares memory addresses, not content. Two strings with identical characters in different memory locations are `==` false but `.equals()` true. This never appears in Python; blind students coming from Python are not conditioned to suspect `==` as a source of String bugs.

**Teaching approach:** Show the broken behavior explicitly. Use `new String("hello") == new String("hello")` which is guaranteed to be `false` even though the strings are identical. Then show `.equals()` which is `true`. Make `.equals()` for Strings a non-negotiable rule from day one.

### Null Pointer Exceptions

`NullPointerException` is the most common Java runtime error. It occurs when you call a method or access a field on a variable that holds `null` (no object reference). Unlike Python's `AttributeError` which gives useful context, Java's NPE message is often terse. Teaching students to recognize and debug NPEs is essential.

---

## 3. Classroom Setup and Configuration

### IDE Configuration

**VS Code with Extension Pack for Java:**
This is the recommended setup. The Extension Pack includes Language Support for Java (Red Hat), Debugger for Java, Java Test Runner, Maven for Java, and Project Manager for Java.

Alternative IDEs to consider:

| IDE | Accessibility | Notes |
|-----|--------------|-------|
| **VS Code + Extension Pack** | High | Recommended. Full accessibility via keyboard. |
| **IntelliJ IDEA Community** | Medium–High | Powerful but complex. More keyboard shortcuts to learn. JetBrains has an accessibility guide. |
| **Eclipse** | Medium | Older UI; can be navigated but more complex accessibility model. |
| **BlueJ** | Low–Medium | Designed for teaching; visual design features may impede accessibility. |
| **DrJava** | Low–Medium | Simple; not actively maintained. |
| **jGRASP** | Low | Visualization-focused; primarily visual. |
| **Greenfoot** | Low | Visual/game-focused; not accessible for screen reader use. |

**VS Code Java Specific Settings:**
```json
{
  "java.completion.enabled": true,
  "java.format.enabled": true,
  "editor.formatOnSave": true,
  "java.saveActions.organizeImports": true,
  "java.completion.importOrder": ["java", "javax", "com", ""],
  "editor.suggestOnTriggerCharacters": true
}
```

**Key accessibility setting:** Enable "Trigger suggestions" on `.` so that typing `myObject.` causes IntelliSense to announce available methods. This allows audio exploration of an object's API.

### JDK Installation Verification

```bash
java --version      # Runtime version
javac --version     # Compiler version
jshell              # Start REPL (Ctrl+D or /exit to quit)
```

All three must work before proceeding. If `jshell` is not found, the student may have installed only the JRE (runtime), not the full JDK. The JDK must be installed.

---

## 4. Spoken Java Conventions

Extend the Python symbol conventions with Java-specific additions:

| Symbol/Pattern | Spoken Form |
|----------------|-------------|
| `public` | "public" |
| `private` | "private" |
| `static` | "static" |
| `void` | "void" (returns nothing) |
| `new` | "new" |
| `this.` | "this dot" |
| `super.` | "super dot" |
| `@Override` | "at-override annotation" |
| `// comment` | "double-slash comment" |
| `/* ... */` | "block comment" |
| `/** ... */` | "JavaDoc comment" |
| `String[]` | "String array" |
| `ArrayList<String>` | "ArrayList of String" |
| `HashMap<String, Integer>` | "HashMap from String to Integer" |
| `throws IOException` | "throws IOException" |
| `System.out.println()` | "sysout" or "system-out-println" |
| `System.out.printf()` | "system-out-printf" |
| `Integer.parseInt()` | "Integer-parse-int" |
| `(int) x` | "cast to int" |
| `null` | "null" |
| `NullPointerException` | "null pointer exception" |
| `ArrayIndexOutOfBoundsException` | "array index out of bounds" |

**Reading a method signature:**
```java
public double calculateArea(double radius) throws IllegalArgumentException
```
*"public double method calculateArea, takes a double called radius, may throw IllegalArgumentException"*

---

## 5. Unit 0–1: Setup and Foundations

### Lesson 0.1: Installing the JDK

#### Instructional Cues

- **Use Adoptium (Eclipse Temurin) rather than Oracle JDK.** The Oracle JDK requires account creation and license agreement navigation. Adoptium is fully open-source and simpler to download.
- **Verify the download before running.** Adoptium provides SHA checksums. Teaching students to verify downloads is a security habit worth establishing.
- **Windows installer tip:** The Adoptium `.msi` installer includes a checkbox for "Set JAVA_HOME variable." Ensure this is checked. Many Java tools (Maven, Gradle, some IDEs) require `JAVA_HOME` to be set.

#### JShell as the First Environment

Before any file-based Java, spend time in JShell:

```
$ jshell
|  Welcome to JShell -- Version 17.0.x
|  For an introduction type: /help intro

jshell> 5 + 3
$1 ==> 8

jshell> "Hello " + "World"
$2 ==> "Hello World"

jshell> int x = 42;
x ==> 42

jshell> System.out.println("Value: " + x);
Value: 42
```

JShell gives immediate auditory feedback — type an expression, hear the result. This is much more accessible for early exploration than the compile-run-read cycle.

JShell commands to teach:
- `/list` — show all code entered so far
- `/edit` — open in editor
- `/vars` — show all variables
- `/methods` — show all methods defined
- `/exit` — quit JShell

#### Thought Experiments

1. *"Python is interpreted — each line runs immediately. Java compiles to bytecode first, then runs. What does this mean for the kind of errors you encounter, and when? If you have a SyntaxError on line 50, in Python you might not discover it until the program reaches line 50. In Java, when do you discover it?"*

2. *"The Java Virtual Machine (JVM) allows the same Java bytecode to run on Windows, macOS, and Linux. The JVM is different on each platform, but the bytecode is the same. What does this tell you about how Java achieves portability? What alternative approaches could a language designer take?"*

3. *"JShell is a Read-Eval-Print Loop (REPL). Python has one; JavaScript has one; many languages have one. But Java didn't have one until 2016. Why might a language's designers add a REPL 20 years after the language was created? What did programmers do without it?"*

4. *"Java was originally designed for embedded systems (like televisions), then became dominant for web servers, then for Android apps. Each time it succeeded in a new domain, it required extending the language. What does this history suggest about the relationship between a language's design and the problems it eventually solves?"*

---

### Lesson 1.2: Your First Java Program

#### Instructional Cues

**Anatomy reading exercise — before typing any code:**
Read the Hello World program aloud, symbol by symbol, using the pronunciation table:

```java
public class HelloWorld {
    public static void main(String[] args) {
        System.out.println("Hello, World!");
    }
}
```

*"public class HelloWorld open-brace newline four-spaces public static void main open-paren String array args close-paren open-brace newline eight-spaces System dot out dot println open-paren quote Hello comma World! close-quote close-paren semicolon newline four-spaces close-brace newline close-brace"*

This exercise establishes pattern recognition for the boilerplate that the student will type hundreds of times. Making it auditorily familiar early reduces cognitive load later.

**Three `System.out` methods:**
```java
System.out.println("With newline at end");     // Most common
System.out.print("No newline at end");          // For prompts
System.out.printf("Pi is %.2f%n", Math.PI);    // Formatted
```

For accessible programs, `printf` is extremely valuable — it produces consistent, predictable output formatting that reads cleanly with a screen reader.

#### Thought Experiments

1. *"Every Java program requires a `public class` whose name matches the file name. Why does Java enforce this one-to-one correspondence? What would break if you could put multiple public classes in one file?"*

2. *"The `main` method signature is exactly `public static void main(String[] args)`. It cannot be `public void main()` or `static void main(String[] args)`. Why is this signature fixed? What does each word contribute?"*

3. *"Java uses curly braces `{}` to delimit code blocks; Python uses indentation. From an accessibility perspective — for a blind programmer — which approach provides better information about structure when read aloud? Consider that braces can be read as 'open block' and 'close block,' while indentation changes require screen reader configuration."*

4. *"`System.out.println()` is long to type but descriptively named. Python's `print()` is short. What naming philosophy does each represent? When does conciseness become ambiguity?"*

---

### Lesson 1.3: Variables and Primitive Data Types

#### Instructional Cues

**Type declaration as specification:**
Frame Java's type declarations positively: *"When you write `int score = 85`, you're telling Java: this variable will always hold a whole number. Java then protects you — if you accidentally try to put a name or a decimal into it, the compiler tells you immediately."*

**The eight primitive types — prioritize four:**
In this curriculum, students need: `int`, `double`, `boolean`, `char`. The others (`byte`, `short`, `long`, `float`) exist but are rarely needed in beginner programs. Introduce the four primary types fully before acknowledging the others exist.

**Type casting demonstration:**
```java
// Widening (automatic)
int i = 100;
double d = i;   // 100 → 100.0, automatic

// Narrowing (explicit, may lose data)
double pi = 3.14159;
int truncated = (int) pi;  // 3.14159 → 3, data LOST

System.out.println("Truncated: " + truncated);  // 3, not 4!
```

The truncation behavior (not rounding) is consistently surprising. Demonstrate it with `(int) 3.9` producing `3`, and ask: "Is this rounding or truncating? What is the difference? When would truncation cause a bug?"

#### Non-Obvious Accessibility Strategies

- **`System.out.printf()` for consistent numeric output:** `printf("Balance: $%.2f%n", balance)` always produces exactly 2 decimal places. Without formatting, `double` values may produce varying numbers of decimal places (`3.0`, `3.14`, `3.1415926535...`) that read differently each time. Consistent formatting makes output more predictable.

- **`Scanner.hasNext___()` methods:** Before calling `scanner.nextInt()`, check `scanner.hasNextInt()`. If the user typed a non-integer, this returns `false` and prevents the exception, allowing graceful re-prompting. For a blind student who may not immediately catch an exception in terminal output, this is defensive programming with real accessibility value.

#### Thought Experiments

1. *"Java's `int` holds values from about -2.1 billion to +2.1 billion. What happens if you exceed this limit (integer overflow)? The value silently wraps around to the opposite extreme. Name a real-world system where integer overflow has caused a documented failure."*

2. *"Java has `int` (primitive) and `Integer` (object). They hold the same values but behave differently. `int` cannot be null; `Integer` can. `int` cannot be used in a `List<int>` — you need `List<Integer>`. Why would a language designer make this distinction? What does it cost? What does it protect against?"*

3. *"Java's `char` holds a single Unicode character. `char c = 'A'` stores the letter A. But `char` is also a numeric type — `(int) 'A'` is `65`. What does this dual nature (character and number) tell you about how computers store text internally?"*

---

## 6. Unit 2: I/O and the Math Class

### Lesson 2.2: Scanner for User Input

#### Instructional Cues

**The Scanner as a wrapper — explain the layers:**
```
Keyboard
  ↓ produces bytes
System.in (InputStream)
  ↓ raw byte stream
new Scanner(System.in)
  ↓ wraps with text-reading methods
scanner.nextLine(), scanner.nextInt(), etc.
```

This layered model explains why `Scanner` is needed rather than reading from `System.in` directly. It also foreshadows file reading where `new Scanner(new File(...))` replaces `new Scanner(System.in)`.

**`nextInt()` / `nextLine()` pitfall — mandatory demonstration:**

```java
Scanner scanner = new Scanner(System.in);
System.out.print("Enter your age: ");
int age = scanner.nextInt();          // Reads "25", leaves "\n" in buffer
System.out.print("Enter your name: ");
String name = scanner.nextLine();     // Reads the leftover "\n" — gets EMPTY string!
System.out.println("Hello " + name + ", age " + age);
// Output: "Hello , age 25" — name is empty!
```

The fix:
```java
int age = scanner.nextInt();
scanner.nextLine();          // Consume the leftover newline
String name = scanner.nextLine();   // Now reads properly
```

Run the broken version first. The student should hear the incorrect output and understand why before seeing the fix.

#### Thought Experiments

1. *"The `Scanner` reads from a 'stream' of input. A stream is a sequence of data that flows from a source to a destination. `System.in` is the keyboard stream. What other streams exist in a typical program? (Think about file streams, network streams, the output stream.)"*

2. *"After `scanner.nextInt()`, there's a leftover newline in the buffer. What IS a buffer? Why does the operating system buffer keyboard input rather than delivering each character the moment a key is pressed?"*

3. *"In GUI (graphical) programs, users fill out forms with text fields and click buttons. There's no `scanner.nextLine()`. What mechanism do GUI programs use to collect user input? How does event-driven GUI input differ from sequential console input?"*

---

## 7. Unit 3: Control Flow

### Lessons 3.1–3.3

#### Instructional Cues

**String comparison — immediate practice:**

```java
String day = "Wednesday";

// Wrong — compares memory addresses
if (day == "Wednesday") {
    System.out.println("Middle of the week");  // May or may not print
}

// Correct — compares content
if (day.equals("Wednesday")) {
    System.out.println("Middle of the week");  // Always correct
}

// Case-insensitive
if (day.equalsIgnoreCase("wednesday")) {
    System.out.println("This works too");
}
```

Create a practice file with 10 comparisons, half using `==` and half using `.equals()`. Ask the student to predict which ones will work correctly before running.

**Switch expressions (Java 14+):**

Modern Java supports switch expressions that return a value:

```java
String dayType = switch (day) {
    case "Monday", "Tuesday", "Wednesday", "Thursday", "Friday" -> "Weekday";
    case "Saturday", "Sunday" -> "Weekend";
    default -> "Unknown";
};
System.out.println(day + " is a " + dayType);
```

This eliminates the fallthrough problem and is more concise. Teach both traditional `switch` (for reading legacy code) and switch expressions (for writing new code).

#### Thought Experiments

1. *"Java uses `&&` for AND, `||` for OR, `!` for NOT. Python uses the words `and`, `or`, `not`. Which approach is more readable when heard aloud by a screen reader? Is there a meaningful accessibility argument for one over the other?"*

2. *"The enhanced for loop `for (String item : list)` is simpler to write than the traditional `for (int i = 0; i < list.size(); i++)`. But sometimes you need the index. Name three operations you can do with the traditional loop that you cannot do (directly) with the enhanced loop."*

3. *"Java's `switch` statement traditionally falls through from one case to the next unless you write `break`. This 'feature' has caused countless bugs. Modern Java (14+) has switch expressions that don't fall through. What does this change tell you about how programming language design evolves in response to real-world usage patterns?"*

4. *"Short-circuit evaluation: `if (obj != null && obj.getValue() > 0)` — if `obj` is null, the second condition is never evaluated. This prevents a NullPointerException. How does this behavior make certain coding patterns possible that would otherwise crash?"*

---

## 8. Unit 4: Arrays and ArrayLists

### Lesson 4.1: Arrays

#### Instructional Cues

**The fixed-size limitation — demonstrate, don't just describe:**

```java
String[] fruits = new String[3];
fruits[0] = "apple";
fruits[1] = "banana";
fruits[2] = "cherry";
fruits[3] = "date";   // ArrayIndexOutOfBoundsException!
```

Let the student hear the exception and analyze the message: `Index 3 out of bounds for length 3`. Ask: "The message gives you two numbers. What are they? What does each tell you?"

**`Arrays.toString()` as mandatory print method:**

The first time `print(fruits)` produces `[Ljava.lang.String;@7a5d012b`, stop and explain: "This is the memory address of the array, not its contents. Java arrays don't have a built-in 'print nicely' behavior. Always use `Arrays.toString(fruits)` or loop through manually."

**The `for` vs `for-each` tradeoff — make it concrete:**

```java
// for-each: simple, clear, but no index
for (String fruit : fruits) {
    System.out.println(fruit);
}

// traditional: more complex, but gives index
for (int i = 0; i < fruits.length; i++) {
    System.out.println(i + ": " + fruits[i]);
}

// The numbered version is more accessible!
```

For blind students, numbered output (showing both index and value) is generally more useful than unnumbered output. Teach the traditional `for` loop for array printing specifically because it enables indexed output.

#### Thought Experiments

1. *"Arrays are stored in contiguous memory — all elements in a row, one after another. This is why accessing by index is fast: the address of element `i` is just the start address plus `i × element size`. Why does this contiguous storage make inserting into the middle of an array slow? What must happen to all the elements after the insertion point?"*

2. *"If you create `String[] arr = new String[5]`, what are the initial values of `arr[0]` through `arr[4]`? Now create `int[] nums = new int[5]` — what are the initial values? Why are the defaults different between String arrays and int arrays?"*

3. *"Two-dimensional arrays in Java are 'arrays of arrays.' This means each row can have a different length — a 'jagged array.' When would a jagged array be more appropriate than a rectangular 2D array? Give a real-world data example."*

---

### Lesson 4.2: ArrayLists

#### Instructional Cues

**Autoboxing — explain the invisibility:**

```java
ArrayList<Integer> numbers = new ArrayList<>();
numbers.add(42);        // 42 (int) is auto-boxed to Integer(42)
int first = numbers.get(0);  // Integer(42) is auto-unboxed to 42
```

This happens invisibly but has a performance cost. For the course, tell students: "Use `ArrayList<Integer>` when you need a flexible list of integers. The boxing/unboxing is automatic but slightly less efficient than an array of `int`."

**Removal by index vs. by value:**

```java
ArrayList<String> list = new ArrayList<>(Arrays.asList("a", "b", "c", "b", "d"));
list.remove(1);            // Removes by INDEX — removes "b" at position 1
list.remove("b");          // Removes by VALUE — removes first "b" found
list.removeAll(Arrays.asList("b", "c"));  // Removes all matching values
```

Ask the student: "If I call `list.remove(0)` on a list of integers `[10, 20, 30]`, does this remove the element at index 0 (which is `10`) or remove the value `0` (which doesn't exist)? How does Java decide?" (Answer: removes index 0, because `0` is an `int`, not an `Integer`.)

#### Thought Experiments

1. *"An `ArrayList` doubles its internal capacity when it runs out of space. If you start with capacity 16 and keep adding elements, when does reallocation occur? Trace the capacity: 16 → 32 → 64 → 128... What is the total cost (in element moves) of adding 1000 elements to an initially empty ArrayList this way? Is this efficient?"*

2. *"Java generics `ArrayList<String>` enforce type safety at compile time. Python lists can hold any types mixed together. When is a typed list (Java style) better? When is a mixed list (Python style) more flexible? Which approach produces more reliable programs?"*

---

## 9. Unit 5: Strings and String Processing

#### Instructional Cues

**String immutability — the Java version:**

In Java, Strings are immutable for the same reason as Python. But Java's `String` object is also **interned** — the JVM may reuse the same `String` object for two variables holding the same literal value. This is why `==` sometimes works for String comparison (when both refer to the same interned object) but is not reliable.

**`StringBuilder` motivation:**

```java
// Inefficient — creates 100,000 String objects
String result = "";
for (int i = 0; i < 100000; i++) {
    result += "x";
}

// Efficient — modifies a single buffer
StringBuilder sb = new StringBuilder();
for (int i = 0; i < 100000; i++) {
    sb.append("x");
}
String result = sb.toString();
```

The `+` in a loop creates a new String object on every iteration, then discards the old one. For small loops this is fine; for large loops it's a significant performance problem. `StringBuilder` maintains a mutable buffer.

#### Thought Experiments

1. *"String concatenation with `+` is convenient but expensive in loops. In Python, the equivalent is also discouraged — use `''.join(list)` instead. What does this common advice across two languages tell you about how immutable strings interact with loops?"*

2. *"Java's `String.format()` and `printf()` use format specifiers like `%s`, `%d`, `%f`. Python uses f-strings with `{}`. What are the accessibility tradeoffs of each approach? Which reads more naturally when heard aloud? Which is easier to type?"*

3. *"Regular expressions are a tiny language inside a programming language. `\\d+` matches one or more digits. `[a-zA-Z]+` matches one or more letters. Why do programmers use regular expressions despite their difficult-to-read syntax? What would the alternative be for complex pattern matching?"*

---

## 10. Unit 6: Methods

#### Instructional Cues

**Method overloading — auditory navigation:**

```java
public static int add(int a, int b) { return a + b; }
public static double add(double a, double b) { return a + b; }
public static int add(int a, int b, int c) { return a + b + c; }
```

When IntelliSense shows overloads in VS Code, pressing `Shift+Alt+F2` (Accessible View) lists them all. Teach students to use this to discover available overloads.

**`void` vs. return type — make the distinction tangible:**

```java
// void: for side effects only
public static void printGreeting(String name) {
    System.out.println("Hello, " + name + "!");
}

// Return type: for computation
public static double calculateTip(double billAmount, double rate) {
    return billAmount * rate;
}

// Using them:
printGreeting("Alice");                      // Standalone call
double tip = calculateTip(50.00, 0.18);      // Must capture return value
System.out.printf("Tip: $%.2f%n", tip);
```

*"`void` methods exist to DO something. Return-type methods exist to CALCULATE something and give you the result. Ask: 'Do I need to use the output later in my code?' If yes, it needs a return type."*

#### Thought Experiments

1. *"Java methods can throw exceptions: `public double sqrt(double n) throws IllegalArgumentException`. This signature tells callers that the method might fail in a specific way. Python has no equivalent syntax. What is the programmer's obligation when they see `throws` in a method signature?"*

2. *"Static methods belong to the class, not to any instance: `Math.sqrt(25)` — you don't need a `Math` object. Instance methods belong to an object: `myString.length()`. What is the conceptual difference? When should a method be static vs. instance?"*

3. *"Method parameters in Java are 'pass by value' for primitives and 'pass by reference' for objects. For primitives: the method gets a copy, and modifying the parameter doesn't affect the original. For objects: the method gets the reference, and modifications to the object's fields DO affect the original. Design a test to confirm this behavior for both cases."*

4. *"Recursion: a method that calls itself. `int factorial(int n) { return n == 0 ? 1 : n * factorial(n-1); }`. Every recursive solution has an iterative equivalent. When is the recursive version clearer? What is the risk of deep recursion (many nested calls)?"*

---

## 11. Unit 7: Classes and OOP

### Extended Instructional Cues

**The mandatory `__str__` equivalent in Java — `toString()`:**

Every student-defined class must override `toString()`. Without it, `System.out.println(myObject)` produces an unreadable string. The `@Override` annotation makes this explicit:

```java
@Override
public String toString() {
    return String.format("Dog[name=%s, age=%d]", name, age);
}
```

Require this in every class from Unit 7 onward. Explain: "When your screen reader reads `System.out.println(myDog)`, it reads whatever `toString()` returns. If you don't define `toString()`, you'll hear a memory address. That's useless."

**JavaDoc comments as accessible documentation:**

Teach this format for every method:

```java
/**
 * Calculates the area of this circle.
 *
 * @return the area as a double, in square units
 * @throws IllegalArgumentException if radius is negative
 */
public double getArea() {
    if (radius < 0) throw new IllegalArgumentException("Radius cannot be negative");
    return Math.PI * radius * radius;
}
```

When IntelliSense shows this method in VS Code, pressing `Shift+Alt+F2` reads the JavaDoc aloud. This makes the student's own code navigable via audio — a profound accessibility benefit.

**The VS Code symbol navigator:**
`Ctrl+Shift+O` opens a dropdown listing all methods in the current file. Type a few letters to filter. This allows jumping to any method by name — much more efficient than arrow-key navigation through a long file.

**Access modifiers — enforce from day one:**

| Modifier | Rule | Reason |
|----------|------|--------|
| `private` on fields | Always | Encapsulation; prevents direct manipulation |
| `public` on getters/setters | When needed | Controlled access |
| `private` on helper methods | Yes | Internal implementation detail |
| `public` on methods the user calls | Yes | Interface to the class |

Establish this as a non-negotiable habit, not a preference. *"Private fields, public interface. Every time."*

#### Thought Experiments

1. *"Encapsulation means the internal state of an object is private. Only its public methods can access or modify it. Why would you want to prevent direct access to `account.balance`? What bugs could occur if balance were public?"*

2. *"Inheritance creates a hierarchy. A `SavingsAccount` extends `BankAccount`. Every `SavingsAccount` is-a `BankAccount`, but not every `BankAccount` is-a `SavingsAccount`. What are the type-safety implications of this? If you have a `BankAccount` variable, can it hold a `SavingsAccount` object?"*

3. *"Java interfaces define contracts — a list of methods that any implementing class must provide. A class can implement multiple interfaces but can only extend one class. Why this asymmetry? What problem does single inheritance solve? What does it prevent?"*

4. *"Design Pattern: the Factory Method creates objects without specifying the exact class. Instead of `new Dog()`, you'd call `AnimalFactory.create("dog")`. What is the advantage of this indirection? When would it be useful?"*

5. *"Object-oriented programming was supposed to model the real world. A `Dog` is-a `Animal`. But real-world relationships are complex — a `FlyingFish` is both a `Fish` and can fly like a `Bird`. How does Java's single-inheritance model handle this situation? What alternatives exist?"*

6. *"Polymorphism means one interface, many implementations. `Animal[] animals = {new Dog(), new Cat(), new Bird()}; for (Animal a : animals) { a.speak(); }` — each animal speaks differently. Why is this more flexible than checking `instanceof` and calling different methods explicitly?"*

#### Alternative Resources

- **"Head First Design Patterns" by Freeman, Robson et al.:** Visual book, but audio-describable concepts. Covers fundamental OOP design patterns. For advanced students.
- **"Effective Java" by Joshua Bloch:** The definitive book on Java best practices. Dense but invaluable for understanding WHY Java is designed the way it is.
- **Oracle Java Tutorials (docs.oracle.com/javase/tutorial/):** Comprehensive, plain HTML, fully accessible. Covers OOP concepts with extensive examples.

---

## 12. Unit 8: Files and Exception Handling

#### Instructional Cues

**Checked vs. unchecked exceptions — the core distinction:**

| Type | Examples | Must Handle? | Why? |
|------|----------|-------------|------|
| **Checked** | `IOException`, `FileNotFoundException`, `SQLException` | Yes — compiler enforces | These are recoverable; programmer should handle them |
| **Unchecked (RuntimeException)** | `NullPointerException`, `ArrayIndexOutOfBoundsException`, `IllegalArgumentException` | No — optional | Usually indicate programming errors; may not be recoverable |

*"Checked exceptions are like warning labels: 'This operation can fail. You must decide what to do if it does.' Unchecked exceptions are usually bugs — the program did something wrong."*

**Try-with-resources — teach first, manual close second:**

```java
// Modern: try-with-resources (always teach this first)
try (BufferedReader reader = new BufferedReader(new FileReader("data.txt"))) {
    String line;
    while ((line = reader.readLine()) != null) {
        System.out.println(line);
    }
} catch (IOException e) {
    System.out.println("Error reading file: " + e.getMessage());
}
// reader is automatically closed here, even if an exception occurred

// Legacy: manual close (show this so students understand what try-with-resources does)
BufferedReader reader = null;
try {
    reader = new BufferedReader(new FileReader("data.txt"));
    // ... use reader
} catch (IOException e) {
    System.out.println("Error: " + e.getMessage());
} finally {
    if (reader != null) {
        try { reader.close(); } catch (IOException e) { /* ignore */ }
    }
}
```

Show the legacy version to explain why try-with-resources exists and what it simplifies.

#### Thought Experiments

1. *"Checked exceptions force you to handle failures at compile time. Critics argue this creates 'exception chaining hell' — every method signature becomes littered with `throws` clauses. Defenders argue it makes failure modes explicit and programs more reliable. Which side do you find more persuasive? Why?"*

2. *"Java's `Path` and `Files` classes (java.nio.file) are a modern replacement for the older `File` class. The older `File` class's `delete()` method returns a `boolean` (true/false) instead of throwing an exception. What is the danger of reporting failure via a return value? What might a programmer accidentally do wrong?"*

3. *"A `NullPointerException` is called 'The Billion Dollar Mistake' by its inventor Tony Hoare. Explain why null references cause so many bugs. Newer languages (Kotlin, Swift) have built-in null safety. What would Java code look like if null didn't exist?"*

---

## 13. Unit 9: Collections, Analysis, and Testing

### JUnit Testing Deep Dive

#### Instructional Cues

**Test output is inherently accessible:**
JUnit produces plain text output: `.` for each passing test, `F` for failures, with descriptive failure messages. This is one of the most screen-reader-friendly outputs in the entire course. Let students experience testing by running a test suite and listening to the results before writing their own tests.

**Test naming convention — sentence style:**
```java
@Test
public void calculateArea_withPositiveRadius_returnsCorrectValue() { }

@Test
public void calculateArea_withZeroRadius_returnsZero() { }

@Test
public void calculateArea_withNegativeRadius_throwsException() { }
```

The naming convention `methodName_condition_expectedBehavior` makes test names read as complete sentences when the test runner announces them. This is both good practice and an accessibility benefit — each test announcement tells you exactly what was tested.

**`assertThrows` — test that exceptions work correctly:**
```java
@Test
public void withdraw_withInsufficientFunds_throwsException() {
    BankAccount account = new BankAccount(100.0);
    assertThrows(InsufficientFundsException.class, () -> account.withdraw(200.0));
}
```

Testing for exceptions is as important as testing for correct outputs. Many beginners only test the "happy path."

#### Thought Experiments

1. *"Test-driven development (TDD) says: write the test first, then write the implementation. How does writing a test first change the way you think about a method? What is forced to be clear before you write a line of implementation?"*

2. *"Mocking means replacing real dependencies (like a database or file system) with fake versions for testing. Why would you want to test a method that reads from a database without using a real database? What complexity does mocking introduce?"*

3. *"A project has 100% test coverage — tests execute every line. Is the software correct? Name a bug that 100% coverage would not catch. (Hint: think about a bug that only appears with certain combinations of inputs.)"*

---

## 14. Units 10–11: Projects and Capstone

### Java Project Architecture

For the capstone, encourage a clean package structure:

```
src/
├── com/
│   └── student/
│       └── datamanager/
│           ├── model/
│           │   └── Contact.java
│           ├── storage/
│           │   ├── DataManager.java
│           │   └── JsonStorage.java
│           ├── ui/
│           │   └── ConsoleUI.java
│           └── Main.java
test/
└── com/
    └── student/
        └── datamanager/
            ├── model/
            │   └── ContactTest.java
            └── storage/
                └── DataManagerTest.java
```

Navigating packages in VS Code: `Ctrl+Shift+E` for Explorer (shows package tree), `Ctrl+P` to open any file by name, `Ctrl+Shift+O` for symbols within the current file.

### IDE-Generated Code Accessibility

VS Code and IntelliJ can generate getters, setters, constructors, and toString. Teach these as time-savers, but require students to read and understand all generated code:

- `Ctrl+Shift+P` → "Java: Generate Getters and Setters"
- `Ctrl+Shift+P` → "Java: Override/Implement Methods"
- `Ctrl+Shift+P` → "Java: Generate toString"

Generated code is correct but often not styled for accessibility (missing JavaDoc, generic names). Require students to add JavaDoc and verify `toString()` output is meaningful when heard.

#### Thought Experiments

1. *"Java in enterprise software is often criticized for having too much 'boilerplate' — code that exists for structural reasons rather than to express logic. How does this boilerplate affect the experience of maintaining a large Java codebase? What tools and patterns does the Java ecosystem provide to reduce it?"*

2. *"Your capstone application stores data in a file. If your team adds a new field to the data class, existing saved files no longer match the new format. This is a 'schema migration' problem. How would you design your storage layer to handle this gracefully?"*

---

## 15. Bridging from Python to Java

For courses that teach Python before Java, use these comparison thought experiments to bridge the languages:

**Syntax bridge table:**

| Python | Java | Notes |
|--------|------|-------|
| `print("Hello")` | `System.out.println("Hello")` | |
| `x = 5` | `int x = 5;` | Java requires type declaration and semicolon |
| `if condition:` | `if (condition) {` | Parens around condition; brace instead of colon |
| `elif` | `else if` | Two words in Java |
| `for item in list:` | `for (Type item : list) {` | Java requires type |
| `def func(x):` | `public static void func(int x) {` | Return type and access modifier required |
| `return x` | `return x;` | Semicolon |
| `# comment` | `// comment` | |
| `None` | `null` | |
| `True`/`False` | `true`/`false` | Lowercase in Java |
| `len(list)` | `list.size()` | Method call, not function |
| `list.append(x)` | `list.add(x)` | |
| `dict["key"]` | `map.get("key")` | |
| `try/except` | `try/catch` | |
| `import math` | `import java.lang.Math;` (or use `Math.` directly) | |

**Thought experiments for bridging:**

1. *"In Python you write `x = 5` and Python figures out the type. In Java you write `int x = 5` and declare the type explicitly. Which approach do you prefer after using both? Which one would you choose for a large team project? For a quick experiment?"*

2. *"Python lists can hold any mixture of types: `[1, 'hello', True, 3.14]`. Java's `ArrayList<String>` can only hold Strings. What bugs does Python's flexibility enable? What bugs does it prevent compared to Java?"*

3. *"Python functions are first-class objects — you can store them in variables, pass them as arguments. In Java (before lambdas), this was much more complex. Java added lambdas in 2014. What does it mean for a language to add a major feature 19 years after it was created?"*

---

## 16. Assessment Strategies

### Alternative Assessment Forms

**Code review presentations:** The student explains their code out loud, as if presenting to a team. The teacher asks questions about design decisions. This tests understanding more authentically than multiple-choice questions.

**Bug-hunting assessments:** Provide a working program with 5–8 intentional bugs of different types. The student must find and fix them using only their screen reader and development tools. This directly tests real-world debugging skill.

**Design walkthroughs:** Give the student a problem and ask them to design the solution — class structure, methods, data structures — without writing any code. Assess the quality of the design, not the typing speed.

**Pair programming sessions:** Two students work on one computer. One dictates code; the other types. Roles swap every 10–15 minutes. This surfaces communication and reasoning skills that solo assessments miss.

---

## 17. Supporting Diverse Needs

### For Braille Display Users

Java's verbose syntax can be particularly burdensome on a braille display with limited width. Strategies:

- Keep lines under 79 characters (PEP 8 applies to style; the Java equivalent is generally under 100).
- Use shorter variable names for very long class hierarchies where the full name is unwieldy.
- Encourage use of IntelliJ IDEA, which has better braille display integration than VS Code in some configurations.

### For Students New to Screen Readers

If a student is still developing screen reader proficiency:
- Begin with JShell instead of file-based programming. Single-line interactions provide immediate feedback.
- Use pair work more extensively until independent navigation is fluent.
- Reduce the number of new concepts per session until screen reader fluency stabilizes.

---

## 18. Alternative and Supplementary Resources

### Textbooks and Reading

| Resource | Level | Format | Accessibility |
|----------|-------|--------|--------------|
| **Introduction to Programming Using Java** (Eck, free online) | Beginner–Intermediate | Free HTML/PDF | HTML version excellent; comprehensive |
| **Big Java: Early Objects** (Horstmann) | Beginner | Print/ebook | Standard university text; clear explanations |
| **Effective Java, 3rd Ed.** (Bloch) | Intermediate–Advanced | Print/ebook | Essential for understanding Java's design philosophy |
| **Head First Java** (Sierra, Bates) | Beginner | Print | Very visual; but text portions accessible; engaging writing style |
| **Java: The Complete Reference** (Schildt) | Reference | Print/ebook | Encyclopedic; good for looking up specific features |
| **Oracle Java Tutorials** (docs.oracle.com) | Beginner–Advanced | Free HTML | Excellent HTML accessibility; definitive |
| **Java Documentation** (javadoc) | Reference | Free HTML | Standard library docs; fully screen-reader-accessible |

### Online Courses and Platforms

| Platform | Course | Accessibility | Notes |
|----------|--------|--------------|-------|
| **edX / MITx 6.092** | Introduction to Programming in Java | High | MIT course; video transcripts available |
| **Coursera** | Java Programming (Duke) | Medium | Free audit available |
| **Codecademy** | Learn Java | Partial | Some UI inaccessible; editor readable |
| **MOOC.fi** (University of Helsinki) | Java Programming MOOC | High | Text-based exercises; excellent accessibility |
| **CodingBat Java** | Java practice problems | High | Plain HTML; no complex UI |
| **Exercism Java Track** | Structured exercises with mentoring | High | Terminal-based; excellent |
| **LeetCode** | Algorithm problems | Medium | Code editor accessible; UI moderate |

**MOOC.fi is especially recommended** for blind students — the University of Helsinki's Java course has no-frills HTML exercises and very clear progression. It is one of the most accessible Java learning platforms available.

### Video and Audio Resources

| Resource | Description | Accessibility |
|----------|-------------|--------------|
| **CS50 AP** (Harvard) | AP Computer Science A course using Java | Captions and transcripts |
| **Derek Banas Java Tutorials** (YouTube) | Concise concept-by-concept tutorials | Captions available |
| **Cave of Programming Java** (YouTube/website) | Beginner Java series | Captions; text summaries |
| **thenewboston Java** (YouTube) | Large beginner series | Captions available |
| **Coding with John** (YouTube) | Clear explanations of Java concepts | Good pacing for beginners |

---

## 19. Quick Reference Sheets

### Java Compilation and Running

```bash
# Compile a single file
javac HelloWorld.java    # Creates HelloWorld.class

# Run compiled program
java HelloWorld          # No .class extension!

# Compile with output directory
javac -d bin src/HelloWorld.java

# Run JShell
jshell                   # Interactive REPL
/exit                    # Exit JShell

# Run tests (if using Maven)
mvn test

# Run tests (if using Gradle)
./gradlew test
```

### Error Type Quick Reference

| Error Type | Common Cause | First Check |
|------------|-------------|------------|
| `cannot find symbol` | Misspelled name or missing import | Spelling; check imports |
| `incompatible types` | Assigning wrong type or missing cast | Type of both sides of assignment |
| `';' expected` | Missing semicolon | End of the line indicated |
| `reached end of file while parsing` | Missing `}` | Count open braces vs close braces |
| `non-static method cannot be referenced from a static context` | Calling instance method from `main` without object | Need to create an object first |
| `NullPointerException` | Calling method on null reference | Which variable is null |
| `ArrayIndexOutOfBoundsException` | Index beyond array length | Print length and the index used |
| `ClassCastException` | Invalid cast | Check `instanceof` before casting |
| `StackOverflowError` | Infinite recursion | Verify base case |
| `NumberFormatException` | `parseInt()` on non-numeric string | Check input string before parsing |

### Scanner Method Reference

```java
Scanner scanner = new Scanner(System.in);

String line   = scanner.nextLine();     // Entire line as String
String word   = scanner.next();         // Single token (whitespace-delimited)
int n         = scanner.nextInt();      // Integer
double d      = scanner.nextDouble();   // Double
boolean b     = scanner.nextBoolean();  // Boolean (true/false)

// Safe versions with type checking
if (scanner.hasNextInt()) {
    int n = scanner.nextInt();
}

// After nextInt(), consume leftover newline:
scanner.nextLine();  // ALWAYS do this before reading a String

// From file
Scanner fileScanner = new Scanner(new File("data.txt"));
// Same methods work; wrap in try-catch for FileNotFoundException

scanner.close();  // Always close when done
```

### Accessible Output Template

```java
// Numbered list output
System.out.println("--- Contacts ---");
for (int i = 0; i < contacts.size(); i++) {
    System.out.printf("%d. %s%n", i + 1, contacts.get(i));
}
System.out.printf("Total: %d contacts%n", contacts.size());

// Menu
System.out.println("\n--- Main Menu ---");
System.out.println("1. Add contact");
System.out.println("2. View all contacts");
System.out.println("3. Search contacts");
System.out.println("4. Delete contact");
System.out.println("5. Save and quit");
System.out.println("-----------------");
System.out.print("Enter option (1-5): ");

// Confirmation messages
System.out.printf("Contact '%s' added successfully.%n", name);
System.out.printf("Found %d matching records.%n", count);
System.out.println("Data saved to contacts.json.");
System.out.println("Error: Name field cannot be empty. Please try again.");
```
