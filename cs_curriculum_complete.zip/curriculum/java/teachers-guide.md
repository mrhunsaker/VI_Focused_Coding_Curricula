# Teacher's Guide: Introduction to Computer Science with Java
## For Visually Impaired Students

---

## How to Use This Guide

This guide accompanies the Java curriculum and follows the same unit/lesson structure. It focuses on:

- **Java-specific accessibility challenges** that differ from Python.
- **Instructional strategies** adapted for students using NVDA, JAWS, VoiceOver, or Narrator.
- **Thought experiments** that build conceptual understanding of Java's design.
- **Common pitfalls** specific to Java's verbosity and strict typing.
- **Bridging from Python** notes for students or teachers who covered Python first.

---

## General Principles for Teaching Java Accessibly

### Java's Verbosity Is a Double-Edged Sword

Java requires more code than Python to accomplish the same task. For sighted students, this is frustrating but manageable — they can skim. For blind students, hearing `public static void main(String[] args)` before they can write a single line of useful code adds significant cognitive overhead.

**Mitigation strategies:**
- Create a starter file template that students can copy for every new program. They modify only the inside of `main()` for early lessons.
- Abbreviate the verbosity in explanation: "For now, treat `public class HelloWorld { public static void main(String[] args) {` as magic words that open the door. We'll understand each part in Unit 7."
- Consider using `jshell` (Java's REPL, available since Java 9) for interactive experimentation. It strips away class and method boilerplate. Run it with `jshell` in the terminal.

### Static Typing Is Auditorily Helpful

Once students understand it, Java's strict typing is actually a benefit for screen reader users:
- The compiler catches type errors before runtime. A blind student doesn't need to search through long output for an error — the compiler tells them exactly what's wrong and where.
- IntelliSense suggestions in VS Code are type-aware. The student hears `int` vs. `String` in suggestions, preventing type mismatches before they happen.

### Error Messages in Java

Java's compile-time errors are verbose. Teach students to:
1. Look at the **first error only** — subsequent errors are often cascading effects of the first.
2. Note the **line number** — jump to it with `Ctrl+G`.
3. Note the **error type** — "cannot find symbol" means a name is wrong; "incompatible types" means a type mismatch.
4. Ignore the rest until the first error is fixed.

---

## UNIT 0–1: Setup and Foundations

### Installing the JDK

#### Instructional Cues

- The JDK installation requires two steps that are easy to confuse: installing Java (the JDK) and configuring VS Code. Walk through each as a distinct phase with a verification step between them.
- `javac --version` confirms the compiler is installed. `java --version` confirms the runtime. Both must work before proceeding.
- The "Extension Pack for Java" in VS Code installs multiple extensions at once. Let the student hear each extension being installed — it builds awareness that VS Code is extensible and that multiple tools work together.

#### Thought Experiments

1. *"Python is interpreted — you run a `.py` file directly. Java compiles to bytecode (`.class` files) first, then runs those. What's the advantage of compilation? What's the disadvantage?"*
2. *"The JVM (Java Virtual Machine) means Java code can run on any operating system without modification — 'write once, run anywhere.' What does the JVM have to do to make this possible?"*
3. *"Before IDEs, Java programmers used text editors and command-line tools. What would the compilation process look and feel like without VS Code? What does an IDE actually add?"*

---

### Lesson 1.3: Variables and Primitive Data Types

#### Instructional Cues

- Java's primitive types are a significant new concept for Python-experienced students. Key distinction: *"In Python, everything is an object. In Java, primitives (`int`, `double`, `boolean`, `char`) are raw values — not objects. `String`, `ArrayList`, and everything you create with `new` are objects."*
- The `int` vs. `long` distinction trips up beginners. Establish the rule: "Use `int` for most whole numbers. Use `long` only when you need numbers larger than ~2 billion." For most programs in this course, `int` is sufficient.
- Integer division is a critical gotcha: `15 / 4` = `3` in Java (unlike Python 3 where it's `3.75`). Demonstrate the truncation immediately and establish the fix: cast one operand to `double`.

#### Non-Obvious Accessibility Strategies

- **`System.out.printf()` is more accessible than concatenation for formatted numbers:** `System.out.printf("Area: %.2f%n", area)` produces cleaner, more predictable output than `"Area: " + area`, which may produce `Area: 78.53981633974483`. Formatted output is more legible when heard.
- **Type announcements in IntelliSense:** In VS Code with the Java extension, autocomplete suggestions include the type of each variable and method return. The Accessible View (`Shift+Alt+F2`) lets students hear these completions. Teach students to use this to discover what type a method returns.

#### Thought Experiments

1. *"Java's `int` can hold values from about -2 billion to +2 billion. What happens if you exceed this limit? This is called 'integer overflow.' When in history have real programs suffered from overflow bugs?"* (Year 2000 bug, video game score counters, etc.)
2. *"In Python, the `+` operator concatenates strings OR adds numbers depending on the types involved. In Java, you must be explicit — you cast or convert before mixing types. Which approach is safer? Which is more convenient?"*
3. *"Java has both `int` and `Integer` — a primitive and its 'wrapper class.' Why would a language need both? When would the object version (`Integer`) be necessary when the primitive (`int`) won't work?"*

---

## UNIT 2–3: I/O, Control Flow

### Lesson 2.2: Scanner for User Input

#### Instructional Cues

- The `import` statement is new for beginners. Explain: *"Java's standard library has thousands of classes. `import` tells Java which ones your program needs. Without `import java.util.Scanner`, Java doesn't know what `Scanner` is."*
- The `Scanner` constructor: `new Scanner(System.in)`. Translate: "`System.in` is the keyboard input stream. `new Scanner(...)` wraps it with tools for reading text line by line."
- The `nextInt()` / `nextLine()` newline pitfall must be demonstrated — not just described. Show the broken behavior first, then explain why it happens, then show the fix.

#### Non-Obvious Accessibility Strategies

- **`scanner.close()` at the end:** Some screen reader configurations produce a warning or unusual audio output when a program exits with an unclosed resource. Teach `scanner.close()` as good hygiene.
- **Prompt design in Java:** Same principle as Python — descriptive prompts with a trailing space: `System.out.print("Enter your age in years: ")`. The `print` (not `println`) keeps the cursor on the same line as the prompt.

#### Thought Experiments

1. *"`System.in` is an InputStream — a raw stream of bytes. `Scanner` wraps it to provide methods like `nextInt()` and `nextLine()`. What does this tell you about Java's design philosophy? Why not just build `nextInt()` directly into `System.in`?"*
2. *"After calling `nextInt()`, there's a leftover newline in the buffer. Why? What is a 'buffer'? Why would the JVM buffer input rather than reading character by character?"*

---

### Lessons 3.1–3.3: Control Flow

#### Instructional Cues

- Java's `switch` statement has explicit `break` statements. Show what happens without `break` — fallthrough. Ask: *"Is fallthrough a bug or a feature? When would you deliberately omit `break`?"* (Combining multiple cases that do the same thing.)
- String comparison: `==` compares references (memory addresses), not content. Two `String` objects with the same text can be `!=` when compared with `==`. This is a recurring source of bugs. Establish the rule on day one: **always use `.equals()` for Strings**.

#### Thought Experiments

1. *"In Java, `==` for Strings compares memory addresses. Why does Python's `==` work correctly for strings without this problem? What is Python doing differently behind the scenes?"*
2. *"Java's enhanced for loop (`for (String item : list)`) looks similar to Python's `for item in list`. What can the traditional for loop do that the enhanced version cannot?"*
3. *"A `switch` statement and a chain of `if-else if` statements can often accomplish the same task. When would you prefer one over the other?"*

---

## UNIT 4: Arrays and ArrayLists

### Lesson 4.1: Arrays

#### Instructional Cues

- Java arrays have a fixed size set at creation. This is the primary limitation that `ArrayList` addresses. Demonstrate the limitation: create an array of size 3, try to add a fourth element → `ArrayIndexOutOfBoundsException`.
- `Arrays.toString(arr)` is the accessible way to print an array. Plain `System.out.println(arr)` prints something like `[I@7f31245a` (a memory address) — meaningless and confusing when heard. Establish `Arrays.toString()` as the standard print method for arrays from the start.

#### Non-Obvious Accessibility Strategies

- **`ArrayIndexOutOfBoundsException` navigation:** This exception includes the invalid index and the array length in its message: `Index 5 out of bounds for length 3`. Teach students to read these numbers and use them to find the bug.
- **`arr.length` vs. `list.size()`:** Arrays use `.length` (a field, no parentheses). ArrayLists use `.size()` (a method, with parentheses). This asymmetry trips up beginners. Create a simple mnemonic: "For raw arrays, `.length` is a measurement. For collections, `.size()` is a question you ask."

#### Thought Experiments

1. *"Fixed-size arrays are more memory-efficient than dynamic ArrayLists. When does this efficiency matter? Can you think of a program where you would choose a fixed array over an ArrayList?"*
2. *"Java arrays are zero-indexed like Python lists. The last valid index is `length - 1`. Why is accessing `arr[arr.length]` an error? What does `arr[arr.length - 1]` access?"*
3. *"A 2D array in Java is actually an 'array of arrays.' What does this mean for accessing elements? What flexibility does this give you that a true 2D grid wouldn't?"*

---

### Lesson 4.2: ArrayLists

#### Instructional Cues

- The generic type syntax `ArrayList<String>` is new. Explain: "The `<String>` part tells Java this ArrayList will only hold Strings. The compiler will warn you if you try to add an integer. This is Java's type safety at work."
- Autoboxing: `ArrayList<int>` is not valid — you must use `ArrayList<Integer>`. Explain: "Remember how `int` is a primitive, not an object? ArrayList can only hold objects. `Integer` is the object version of `int`."

#### Thought Experiments

1. *"ArrayList grows automatically when you add items beyond its current capacity. How do you think it does this internally? What does 'dynamic resizing' cost in terms of time and memory?"*
2. *"When you remove an item from the middle of an ArrayList, all subsequent items shift left by one. What does this mean for a program that is removing many items? What alternative data structure would handle this more efficiently?"*

---

## UNIT 5–6: Strings and Methods

### Lesson 5.1: Strings

#### Instructional Cues

- Java Strings are immutable — the same as Python. All methods return new Strings; they don't modify the original. Demonstrate the classic mistake: `str.toUpperCase(); System.out.println(str);` → still lowercase. Ask: "Where did the uppercase version go?" (Nowhere — it was created and immediately discarded.)
- String concatenation with `+` in a loop creates many temporary String objects and is inefficient. Introduce `StringBuilder` for loop concatenation as a professional habit.

#### Thought Experiments

1. *"Java's String is immutable. If you do `str = str + 'x'` in a loop 1000 times, Java creates 1000 intermediate String objects. Why is `StringBuilder` more efficient? What is it doing differently?"*
2. *"`.equals()` compares String content. `.equalsIgnoreCase()` ignores case. When would you use each? Are there cases where ignoring case could cause a bug?"*

---

## UNIT 7: Classes and OOP

### Lessons 7.1–7.5

#### Instructional Cues

- Java OOP requires a full class file for every class — including simple data holder classes. This is more overhead than Python's class definitions. Normalize this: *"In Java, each class typically lives in its own file. The file name must exactly match the class name, including capitalization."*
- Access modifiers are enforced at compile time in Java, unlike Python's convention-based privacy. Establish the rule: "Instance variables are `private`. Methods that other classes need are `public`. Methods used only internally are `private`."
- Getters and setters feel tedious but serve a purpose: they let you add validation later without changing how external code uses the class. Demonstrate: a `setAge()` method that rejects negative ages would be impossible with a `public` field.

#### Non-Obvious Accessibility Strategies

- **JavaDoc comments as navigable documentation:** Teach students to write JavaDoc comments above methods:
  ```java
  /**
   * Returns the area of this circle.
   * @return area as a double
   */
  public double getArea() { ... }
  ```
  VS Code displays these in the Accessible View when navigating to a method. They become self-generated documentation that the student can hear while navigating their own code.
- **Override annotation:** `@Override` above a method causes a compile error if the method doesn't actually override anything. This protects against typos in method names — especially valuable for blind students who can't visually scan for mismatches.

#### Thought Experiments

1. *"Java enforces `private` — code outside the class cannot access private fields at all. Python has only convention (`_variable`). Which philosophy is better for a large team? For a solo learner?"*
2. *"What is the difference between a constructor and a method that initializes values? Could you create a `Dog` object and then call `dog.initialize('Buddy', 3)` instead of having a constructor? What would be wrong with that approach?"*
3. *"Java's `final` keyword applied to a class prevents inheritance. Why would a library author make a class `final`? What problems could unrestricted inheritance cause?"*
4. *"Interfaces define a contract: 'any class that implements this interface must provide these methods.' Why is this useful? How does it differ from abstract class inheritance?"*
5. *"Design a class hierarchy for a library catalog system. What is the base class? What subclasses make sense? What methods belong in the base class? What methods should be abstract?"*

---

## UNIT 8: Files and Exceptions

#### Instructional Cues

- Java's checked vs. unchecked exceptions: *"In Java, some exceptions are 'checked' — the compiler forces you to handle them. `IOException` is checked. You must either `catch` it or declare `throws IOException` in your method signature. This is Java making you think about failure modes."*
- Try-with-resources is the modern Java approach: `try (Scanner sc = new Scanner(new File(...))) { ... }`. The resource is automatically closed when the block ends, even if an error occurs. Teach this pattern from the start for file operations.

#### Thought Experiments

1. *"Checked exceptions force programmers to handle errors. Some languages (like Python) have no checked exceptions — you handle errors when you choose to. Which approach produces more reliable software? Which produces faster development?"*
2. *"Java's exception hierarchy has `Throwable` at the top, then `Error` (don't catch this — JVM problems) and `Exception` (catch this — program problems). Why distinguish between them? When would you NOT want to catch an exception?"*

---

## UNIT 9: Collections and Testing

### JUnit Testing

#### Instructional Cues

- JUnit test output is accessible: a summary line shows passes, failures, and errors. VS Code's test runner produces this in the terminal. The Accessible View reveals detailed failure messages.
- Test-driven development (TDD): for advanced students, introduce the practice of writing tests before writing the implementation. This forces clear thinking about what a function should do before worrying about how.

#### Thought Experiments

1. *"JUnit's `@Before` (JUnit 4) / `@BeforeEach` (JUnit 5) method runs before every test. What problem does this solve? What problem does it NOT solve — i.e., what might one test do that still affects another?"*
2. *"You're testing a method that reads from a file. The test passes on your computer but fails on another computer. What might cause this? How would you design the test to avoid file system dependencies?"*
3. *"`assertThrows()` verifies that a method throws an exception under specific conditions. Why is testing for exceptions as important as testing for correct outputs?"*

---

## UNIT 10–11: Projects and Capstone

### Java-Specific Project Guidance

#### Instructional Cues

- Encourage students to plan their class hierarchy before writing any code. A text document listing: class name, fields, constructor parameters, public methods, relationships with other classes.
- For the capstone, the architecture recommendation (model/storage/ui/Main separation) is especially important in Java because file size grows quickly. A single 500-line Java file is hard for any programmer to navigate — especially one using a screen reader.

#### Non-Obvious Accessibility Strategies

- **Package organization as audio navigation:** Teach students to organize code into packages (folders). VS Code's Java extension shows packages in the Explorer, allowing navigation by category: `model`, `storage`, `ui`. This is more accessible than a flat directory of Java files.
- **IDE-generated getters/setters:** VS Code can generate getters and setters automatically. Use `Ctrl+Shift+P` → "Java: Generate Getters and Setters." Teach this to save typing and prevent errors in boilerplate code — but require that students read and understand the generated code.

#### Thought Experiments

1. *"In a real Java project, a team of 10 programmers might each work on different classes. Why does Java's access modifier system (public/private/protected) become even more important in this context?"*
2. *"Your capstone persists data to a file. If the file format needs to change (e.g., you add a new field to your data class), what happens to existing saved data? How would you handle this migration problem?"*
3. *"Java is often used in enterprise software — banking systems, hospital records, airline reservations. Why might a company choose Java's strict typing and compile-time checks over a more dynamic language for these applications?"*

---

## Bridging Concepts: Python to Java

For courses that teach Python first and Java second, these thought experiments help students connect the two languages:

1. *"Python's `print()` and Java's `System.out.println()` both display text. Why does Java's version require so many words? What does each word mean?"*
2. *"In Python you write `x = 5` to create an integer variable. In Java you write `int x = 5`. What information does the Java version contain that the Python version doesn't? Why might Java require this extra information?"*
3. *"Python automatically handles memory management. In older C programs, you had to manually free memory. Java uses 'garbage collection' — automatic memory management like Python, but with different tradeoffs. What would a programmer need to think about if they had to manage memory manually?"*
4. *"Python's `for item in my_list:` and Java's enhanced for loop `for (String item : myList):` look similar. What does Java require that Python doesn't? Why?"*
5. *"Python duck typing says 'if it looks like a duck and quacks like a duck, it's a duck.' Java says 'I need to see your birth certificate proving you're a duck.' What bugs does Java's approach prevent? What flexibility does Python's approach allow?"*
