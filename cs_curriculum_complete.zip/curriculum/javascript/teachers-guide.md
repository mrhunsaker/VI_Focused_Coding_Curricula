# Teacher's Guide: Introduction to Computer Science with JavaScript
## For Visually Impaired Students

---

## How to Use This Guide

This guide accompanies the JavaScript curriculum. It addresses JavaScript's unique teaching challenges for blind students — including asynchronous programming, the unusual type system, and the browser/Node.js split — and provides instructional strategies, thought experiments, and accessibility-specific techniques throughout.

---

## General Principles for Teaching JavaScript Accessibly

### The Unique Challenge of JavaScript's Flexibility

JavaScript is the most permissive major programming language. It will silently convert types, allow calling undefined functions, and produce `NaN` instead of crashing. This is a double-edged accessibility concern:

**Benefit:** Fewer runtime crashes mean less time hunting through error output.

**Risk:** Silent failures are harder to detect without visual scanning. A program that produces `NaN` for an answer may run to completion without any error message.

**Mitigation:** Teach defensive programming habits from the start:
- Check input values before using them: `if (isNaN(number)) { ... }`
- Log intermediate values liberally: `console.log('after conversion:', number)`
- Use strict equality (`===`) always — loose equality (`==`) silently converts types in surprising ways.

### `console.log()` Is Your Primary Diagnostic Tool

For a blind student, `console.log()` is even more central than for sighted programmers. Terminal output is the window into program state. Teach students to log:
- Input values immediately after receiving them
- The results of every calculation before using them
- The state of arrays and objects before and after modifications
- A message at the start of every significant function: `console.log('Entering calculateTotal...')`

This is not clutter — during development, it is essential navigation. Teach students to remove or comment out debug logs before finalizing their program.

### Asynchronous Programming Is Conceptually Hard

JavaScript's asynchronous nature — especially `async`/`await` — is a conceptual hurdle. The programs in this curriculum use `async/await` for user input, which is the cleanest available pattern in Node.js. Still, it requires careful explanation.

The key mental model: *"When your program hits `await`, it pauses that function and waits for the response. The rest of the universe can still run. When the response arrives, the function continues from where it paused."*

Do not try to explain the full event loop in early lessons. Introduce it as: "This is a pattern we use for waiting for input. The `async` and `await` keywords make our input function pause politely instead of blocking everything."

---

## UNIT 0–1: Setup and Foundations

### Lesson 0.1: Installing Node.js

#### Instructional Cues

- Node.js and npm (Node Package Manager) are bundled together. Confirm both with `node --version` and `npm --version`. Both must work.
- The Node.js REPL (interactive shell) is excellent for early experiments. Start by running `node` with no arguments and showing the student they can type JavaScript and get immediate responses. This is more engaging than writing files from the start.
- Demonstrate the difference between running in the REPL and running a file:
  - REPL: immediate, interactive, no file needed.
  - `node filename.js`: runs a complete program, exits when done.
  Both are valuable; use the REPL for experimenting and files for programs.

#### Non-Obvious Accessibility Strategies

- **Node.js REPL is highly accessible:** The REPL processes one expression at a time and prints the result immediately. It is essentially an accessible, spoken-feedback calculator. Use it heavily in early lessons for arithmetic and type exploration.
- **`.exit` vs. `Ctrl+C` twice:** Teach both ways to exit the REPL. `Ctrl+C` twice is faster; `.exit` is more explicit. Some students prefer explicit commands.

#### Thought Experiments

1. *"JavaScript was originally designed only for browsers. Why did someone need to make it run outside the browser? What becomes possible when JavaScript can read files and access the network directly?"*
2. *"Node.js uses an 'event loop' to handle many tasks without using multiple threads. Why is this design appropriate for a language that handles many web requests at once?"*
3. *"npm has over 2 million packages. What are the risks of depending on so many third-party packages? What is the benefit? How do companies manage these tradeoffs?"*

---

### Lesson 1.3: Data Types

#### Instructional Cues

- JavaScript has only one number type: `Number`. Both `42` and `42.5` are numbers. This is simpler than Python's `int`/`float` split, but creates the surprising result that `0.1 + 0.2` is `0.30000000000000004` — a floating-point precision issue.
- `null` vs. `undefined`: *"`null` is an intentional empty value — a programmer put it there. `undefined` means a variable was declared but never given a value — it's the absence of initialization."*
- `typeof null` is `"object"` — a famous JavaScript bug that was never fixed for backward compatibility reasons. Point this out explicitly so students aren't confused.
- `NaN` (Not a Number) is the result of invalid number operations: `Number("abc")` = `NaN`. The bizarre fact: `NaN === NaN` is `false`. To check for `NaN`, always use `isNaN()`.

#### Non-Obvious Accessibility Strategies

- **`typeof` as an audio diagnostic:** `console.log(typeof myVar)` is extremely useful for students who cannot visually inspect variable state. Teach this as a debugging reflex alongside `console.log(myVar)`.
- **String coercion confusion:** JavaScript silently converts types more aggressively than Python. `"5" + 3` = `"53"` (concatenation) but `"5" - 3` = `2` (subtraction). Without testing intermediate values, this can produce output that sounds wrong but triggers no error. Require students to test type expectations explicitly during development.

#### Thought Experiments

1. *"JavaScript has one number type for both integers and decimals. Python has two (`int` and `float`). What are the tradeoffs? What problems does JavaScript's single type prevent? What problems does it create?"*
2. *"`NaN` stands for 'Not a Number,' yet `typeof NaN` is `'number'`. Explain why this makes sense logically, even though it seems contradictory."*
3. *"JavaScript's `==` operator converts types before comparing: `0 == false` is `true`, `"" == false` is `true`. How many of these can you predict before testing them? Why is `===` almost always the right choice?"*
4. *"`undefined` is a value in JavaScript. `null` is another value. `0`, `""`, and `false` are also falsy. What does this suggest about how JavaScript thinks about 'nothing'? Is one value for 'nothing' better than many?"*

---

## UNIT 2: Numbers, Input, and the Math Object

### Lesson 2.2: Getting User Input in Node.js

#### Instructional Cues

- The `readline` module approach requires understanding callbacks or promises. Use the promise-based approach with `async/await` exclusively in this curriculum — it reads linearly and is much easier to follow aurally.
- The `input.js` helper module pattern is recommended because it hides the complexity of `readline` setup. Once it's written once, students `require('./input')` and use `askQuestion()` without worrying about the internals.
- Walk through the `async function main()` / `main()` pattern explicitly: *"Every time you want to ask the user something, your main function must be `async`. The `await` keyword pauses the function and waits for the response. When it arrives, the next line runs."*

#### Non-Obvious Accessibility Strategies

- **Asynchronous code produces non-linear output:** If a student accidentally omits `await`, the program continues executing before the answer arrives — producing confusing output. Teach them to look for this pattern when output seems out of order: "If you see results before the prompts, you're probably missing an `await`."
- **The `rl.close()` call:** Not calling `rl.close()` at the end of the program leaves the process running — the terminal appears to hang. This is confusing for any user but especially confusing for a screen reader user who can't see that the program is technically still running. Always close the `readline` interface.

#### Thought Experiments

1. *"Node.js input uses callbacks or promises because input is asynchronous. What does 'asynchronous' mean? Why is waiting for user input an asynchronous operation, even though it seems like a simple pause?"*
2. *"The `readline` module wraps `process.stdin` (standard input). What is stdin? What other 'standard' streams does Node.js provide?"*
3. *"The `input.js` helper module abstracts away the complexity of `readline`. What does 'abstraction' mean in this context? What are you hiding, and why?"*

---

## UNIT 3: Control Flow

### Lessons 3.1–3.3: Conditionals and Loops

#### Instructional Cues

- The `===` vs. `==` distinction needs emphasis beyond just "use ===." Demonstrate a failure: `"5" == 5` is `true` — this compares a string to a number and says they're equal. Ask: "If you're checking whether a user's input equals the number 5, and `input()` always returns a string, will `"5" == 5` work? Is this a problem or a convenience?" (It masks the type confusion — dangerous.)
- Truthy and falsy values are deeply JavaScript-specific. Provide a memorable list: `false`, `0`, `""` (empty string), `null`, `undefined`, `NaN` — these are all falsy. Everything else, including `"false"` (a non-empty string!), is truthy.
- The `for...of` loop is more readable than the traditional `for` loop for iterating arrays. Teach `for...of` first for array iteration, traditional `for` for when you need the index.

#### Non-Obvious Accessibility Strategies

- **Switch statement fallthrough:** JavaScript's `switch` falls through by default (like Java). Forgetting `break` means multiple cases run. Since fallthrough doesn't produce an error, it's a silent logic bug. Teach the habit of always writing `break` and `default`.
- **`for...in` on arrays is dangerous:** `for (const i in myArray)` iterates over the keys of the array — which are the indices as strings, plus any properties added to the Array prototype. This can produce unexpected output. Establish the rule: "`for...in` is for objects. `for...of` is for arrays."

#### Thought Experiments

1. *"In JavaScript, `if (userName)` is equivalent to `if (userName !== '' && userName !== null && userName !== undefined)`. Is this shorthand helpful or dangerous? In what situation could this implicit check cause a bug?"*
2. *"JavaScript's `switch` has fallthrough (execution continues to the next case unless you `break`). This is a design choice inherited from C. When is fallthrough intentionally useful? When is it a bug trap?"*
3. *"The ternary operator `condition ? trueValue : falseValue` can be nested: `a ? b ? c : d : e`. Is nesting ternaries good style? What are the readability tradeoffs when read aloud by a screen reader?"*

---

## UNIT 4: Arrays and Objects

### Lesson 4.1: Arrays and Functional Methods

#### Instructional Cues

- JavaScript's `map`, `filter`, and `reduce` are powerful and idiomatic. For blind students, they're especially valuable because they produce clean, deterministic output from a single readable expression.
- Build up to chaining gradually. First `map` alone, then `filter` alone, then chain them with a deliberate narrative: "I want the squares of all even numbers. Step 1: filter to keep only evens. Step 2: map each even to its square." Then show how this translates to code.
- `reduce` is the hardest to explain. Use the accumulator metaphor: *"Imagine walking through a list of numbers carrying a running total in your pocket. At each number, you add it to your pocket total. `reduce` is that walk."*

#### Non-Obvious Accessibility Strategies

- **Method chaining and the Accessible View:** Long chains of `.filter().map().reduce()` can be hard to hear all at once. Teach students to break chains into named intermediate variables during development:
  ```javascript
  const evens = numbers.filter(n => n % 2 === 0);
  const squares = evens.map(n => n ** 2);
  const total = squares.reduce((sum, n) => sum + n, 0);
  ```
  This produces intermediate values you can log and hear at each step. After confirming correctness, the chain can be combined if desired.
- **Printing arrays accessibly:** `console.log(myArray)` in Node.js prints `[ 1, 2, 3 ]` — reasonably accessible. But for long arrays, teach `myArray.forEach(item => console.log(item))` to hear each element on its own line.

#### Thought Experiments

1. *"`map` creates a new array. `forEach` doesn't return anything. They both iterate over every element. When would you use `map` vs. `forEach`? What principle governs this choice?"*
2. *"`reduce` can implement `map` and `filter`. `map` can implement `filter` (sort of). What does it mean that `reduce` is the 'most powerful' of the three? Is there anything these methods can do that a traditional `for` loop cannot?"*
3. *"Arrow functions `(n) => n * 2` are shorter than traditional functions `function(n) { return n * 2; }`. Beyond brevity, arrow functions behave differently with respect to `this`. Why might you still prefer traditional functions in some contexts?"*

---

### Lesson 4.2: Objects

#### Instructional Cues

- Objects in JavaScript are fundamentally different from Java's class instances (though they look similar). A JavaScript object is just a collection of key-value pairs — no class required. Emphasize: *"You can create an object in JavaScript without ever defining a class. The object literal `{ name: 'Alice', age: 15 }` creates an object immediately."*
- Destructuring is syntactically dense but extremely common in modern JavaScript. Introduce it visually, then describe the audio: "`const { name, age } = person` creates two variables — `name` and `age` — and fills them with the values from `person.name` and `person.age`."
- Spread syntax (`...`) is equally common and equally dense. Frame it: "The spread operator 'unpacks' an array or object — it's like opening a bag and laying all the contents out."

#### Non-Obvious Accessibility Strategies

- **`Object.keys()` / `Object.values()` / `Object.entries()`:** These convert an object's structure into arrays, which can then be iterated with `for...of` or `forEach`. This is often more accessible than `for...in` because the output is more predictable.
- **Nested object access errors:** `person.address.city` throws a `TypeError` if `address` is `undefined`. JavaScript's optional chaining operator `person?.address?.city` returns `undefined` instead of throwing. Teach this pattern for accessing nested data that may be missing.

#### Thought Experiments

1. *"JavaScript objects are flexible — you can add, delete, and modify properties at any time. Java objects are strictly typed — their fields are fixed. Which philosophy is better for representing real-world data that changes? For representing mathematical concepts that don't change?"*
2. *"Destructuring and the spread operator are ES6+ features — they didn't exist in the original JavaScript. What does their introduction tell you about how programming languages evolve? What problems were they solving?"*
3. *"What is the difference between copying an object with `const copy = { ...original }` (shallow copy) and a deep copy? What would `{ ...original }` miss if `original` contained nested objects?"*

---

## UNIT 5–6: Strings and Functions

### Lesson 6.1: Functions

#### Instructional Cues

- JavaScript has four ways to define functions: declarations, expressions, arrow functions, and methods. Focus on arrow functions as the primary style for this curriculum — they're idiomatic in modern JavaScript.
- Higher-order functions (functions that take or return other functions) are a conceptual leap. Introduce with a concrete example: "The `setTimeout` function takes another function as its first argument — 'call this function after 1 second.' Passing functions around is normal JavaScript."
- Closures are not optional in JavaScript — they're everywhere. Explain with the counter example: *"The `count` variable in `makeCounter()` is captured by the returned functions. Even after `makeCounter()` finishes running, `count` lives on inside the closure."*

#### Non-Obvious Accessibility Strategies

- **Function names matter more in JS than in Python:** In Python, screen reader users can navigate to a function by searching for `def`. In JavaScript, arrow functions assigned to variables (`const calculate = (x) => x * 2`) must be searched by the variable name. Teach consistent, descriptive naming and the habit of using `Ctrl+Shift+O` (symbol picker) to navigate functions.
- **Arrow function implicit returns:** A single-expression arrow function `(n) => n * 2` implicitly returns the result. A block body `(n) => { return n * 2; }` requires explicit `return`. The difference is auditorily invisible — only the braces distinguish them. Teach students to read their arrow functions carefully, checking whether `{` is present.

#### Thought Experiments

1. *"Functions are 'first-class citizens' in JavaScript — they can be stored in variables, passed as arguments, returned from other functions. What does this enable that a language where functions are NOT first-class cannot do?"*
2. *"A closure captures variables from its surrounding scope. This means closures 'remember' values even after their enclosing function returns. What are the memory implications of closures? Could you 'leak' memory with closures?"*
3. *"JavaScript's function declarations are 'hoisted' — you can call a function declared with `function` before the declaration appears in the code. Arrow functions and function expressions are NOT hoisted. When is this distinction practically important?"*
4. *"Pure functions take inputs and return outputs with no side effects. `console.log()` is a side effect. What are the benefits of writing pure functions? Can you write a useful program with ONLY pure functions?"*

---

## UNIT 7: Classes and OOP

#### Instructional Cues

- JavaScript classes (ES6+) are syntactic sugar over prototype-based inheritance. The underlying mechanism is different from Java's class system, but the syntax looks similar. Do not attempt to explain prototypes at this stage — use the class syntax as a clean abstraction.
- Private fields (`#fieldName`) are a very recent addition to JavaScript. Confirm that Node.js 18+ supports them before using.
- The `toString()` method: unlike Java which has a built-in `Object.toString()`, JavaScript's `console.log(myObject)` produces a different output than `String(myObject)`. Teach `toString()` as a way to control what appears when the object is converted to a string.

#### Non-Obvious Accessibility Strategies

- **Class introspection:** To see all methods on a class instance, `Object.getOwnPropertyNames(MyClass.prototype)` returns an array of method names. This is a useful audio exploration technique for discovering what a class can do.
- **`instanceof` for type checking:** `myDog instanceof Dog` returns `true` if `myDog` was created with `new Dog(...)`. Teach this as an audio alternative to visually inspecting an object's type.

#### Thought Experiments

1. *"JavaScript's class syntax is 'syntactic sugar' over prototypes. What does this mean? If the underlying mechanism is prototypes, why add class syntax at all?"*
2. *"In JavaScript, you can add a new method to an existing built-in class: `Array.prototype.sum = function() { ... }`. This is called 'monkey-patching.' Why is this powerful? Why do experienced JavaScript developers warn against it?"*
3. *"Private fields with `#` are enforced by the JavaScript engine. Before they existed, developers used closures to achieve privacy. Design a counter class using closures instead of `#private`. What do you lose compared to the `#` approach?"*

---

## UNIT 8: Files, Modules, and Error Handling

### Lesson 8.1: Files

#### Instructional Cues

- Synchronous vs. asynchronous file I/O: for this curriculum, use synchronous (`readFileSync`, `writeFileSync`) in scripts that read a file at startup or write at the end. Use async versions for programs that continue doing work while waiting for file operations.
- The `utf8` encoding argument: *"Files are bytes. 'utf-8' tells Node.js to interpret those bytes as text characters. Without it, you'd get a `Buffer` object — raw bytes. Always specify `'utf8'` when reading text files."*
- `ENOENT` in error codes: this stands for "Error NO ENTry" — the file or directory does not exist. Teach students to recognize common error codes: `ENOENT` (not found), `EACCES` (permission denied), `EEXIST` (already exists).

#### Thought Experiments

1. *"Synchronous file reading blocks the entire program while waiting. Asynchronous file reading allows other code to run. For a command-line script that reads one file on startup, does this distinction matter? For a web server handling 1000 requests per second, does it matter more?"*
2. *"Node.js has both an older callback style and a newer promise style for async operations. `fs.readFile(path, callback)` vs. `fs.promises.readFile(path)`. Why are there two APIs? Which would you choose, and why?"*

---

### Lesson 8.2: Error Handling

#### Instructional Cues

- JavaScript's `try-catch` is synchronous — it does NOT catch errors in callbacks or promises. This is a common source of confusion. Demonstrate: if an error occurs inside a callback function, `try-catch` around the outer code will not catch it. For async/await code, `try-catch` DOES work.
- Custom error classes improve diagnostic clarity. When a student hears `ValidationError: email field is required` in the terminal, they know immediately what went wrong and where to look.

#### Thought Experiments

1. *"Throwing an error in JavaScript immediately stops the current function and unwinds the call stack until something catches it. If nothing catches it, the program crashes. What is the philosophy behind this 'propagation' model? How is it different from returning an error code?"*
2. *"Some JavaScript libraries return errors as the first argument to a callback: `function(err, data)`. Others return promises that reject on error. Others throw. What are the tradeoffs of each approach for readability and reliability?"*

---

## UNIT 9: Modules, Collections, and Testing

### Lesson 9.5: Testing with Jest

#### Instructional Cues

- Jest's output is accessible: dots for passes, `FAIL` with detailed descriptions for failures. The `--verbose` flag produces more detailed output that reads better with a screen reader: `npx jest --verbose`.
- Organize test files to mirror source files. If `src/math.js` exists, tests go in `tests/math.test.js` or `src/math.test.js`. This predictable structure allows navigation by name.
- The `describe` / `test` grouping reads like English when listened to: "describe 'add function': test 'adds two positive numbers'." Encourage this English-sentence style for all test descriptions.

#### Non-Obvious Accessibility Strategies

- **`--runInBand` for serial output:** By default, Jest may run tests in parallel, producing interleaved output that's hard to follow aurally. `npx jest --runInBand` runs tests serially, producing sequential output.
- **`--verbose` flag:** Standard Jest output only shows a summary. `--verbose` shows each test name as it runs, which is much more informative when heard.

#### Thought Experiments

1. *"Jest's `expect(value).toBe(expected)` uses `===`. `expect(value).toEqual(expected)` does a deep comparison of objects. When does the difference matter? Predict: would `expect([1,2,3]).toBe([1,2,3])` pass or fail?"* (It fails — two different array objects, even with the same content.)
2. *"What would you test for a function that reads user input and stores it? What is difficult about testing functions that have side effects or require user interaction?"*
3. *"Test coverage reports show what percentage of your code is exercised by tests. Is 100% test coverage a reasonable goal? Is it a sufficient measure of software quality?"*

---

## UNIT 10–11: Projects and Capstone

### JavaScript-Specific Project Guidance

#### Instructional Cues

- JavaScript projects quickly accumulate dependencies managed by `package.json`. Teach students to initialize a project properly:
  ```bash
  mkdir my-project
  cd my-project
  npm init -y
  ```
  The resulting `package.json` is human-readable text and fully accessible.
- Module organization: break the project into files mirroring concerns. The `require('./models/contact')` pattern makes navigation by name possible.

#### Non-Obvious Accessibility Strategies

- **`package.json` scripts as commands:** Teach students to add convenience scripts to `package.json`:
  ```json
  "scripts": {
      "start": "node index.js",
      "test": "jest --verbose"
  }
  ```
  Then `npm start` and `npm test` are consistent commands regardless of the specific entry point filename. This reduces the cognitive load of remembering filenames.
- **`console.table()` for arrays of objects:** `console.table([{name: 'Alice', age: 15}, {name: 'Bob', age: 14}])` produces a formatted table in the terminal. In some screen readers, this table is read column by column. Test whether it's accessible in your specific setup before teaching it as the primary display method.

#### Thought Experiments

1. *"JavaScript runs in both browsers and Node.js. If you ever move your project to the browser, what would need to change? What code would transfer directly? What would need to be rewritten?"*
2. *"Your project uses a third-party package from npm. A security vulnerability is discovered in that package. Who is responsible for your application's security? What is your obligation to update?"*
3. *"JavaScript is single-threaded but can handle many I/O operations concurrently through its event loop. If your data manager program needed to handle 100 users at once (as a web server), what would change architecturally? What would stay the same?"*

---

## Cross-Language Comparison: JavaScript vs. Python vs. Java

For courses covering all three languages, these thought experiments help students build a metalinguistic understanding:

1. *"Python, Java, and JavaScript all have loops, variables, functions, and classes. Yet they feel very different to program in. What is the most fundamental difference between how each language approaches programming?"*

2. *"In Python, indentation defines code blocks. In Java and JavaScript, curly braces do. From an accessibility perspective — as a screen reader user — which approach gives you more reliable information about code structure, and why?"*

3. *"Each language has a primary use case: Python for data science and scripting, Java for enterprise software, JavaScript for web development. Why hasn't one language 'won' and replaced the others? What does this diversity tell you about the nature of programming problems?"*

4. *"Error handling looks different in each language: Python's `try/except`, Java's checked and unchecked exceptions, JavaScript's `try/catch` with promise `.catch()`. What do these approaches have in common? What does each one optimize for?"*

5. *"All three languages have a standard library — built-in tools that come with the language. Python's is large and batteries-included. Java's is very large and mature. JavaScript's (for Node.js) is smaller and relies more on npm packages. What are the advantages and risks of each approach?"*

6. *"If you were starting a new software project today, which language would you choose? What factors would guide that decision? Is there a 'best' language, or does it depend on context?"*

---

## Universal Accessibility Checklist for All Languages

Use this checklist to evaluate any program written in this curriculum for accessibility:

### Program Output
- [ ] Every action produces a confirmation message.
- [ ] Every error produces an informative, human-readable message.
- [ ] Lists are printed one item per line with a label or number.
- [ ] No information is conveyed only through formatting (bold, color, indentation of output).
- [ ] File names and locations are printed when files are created or modified.

### User Input
- [ ] Every prompt clearly describes what is expected (type, format, range).
- [ ] Invalid input produces a clear explanation and re-prompts.
- [ ] Menu items are numbered for easy selection.
- [ ] A "help" command or option is available.

### Code Quality for Screen Reader Navigation
- [ ] Functions and methods have descriptive names.
- [ ] Variables have descriptive names (no single letters except loop counters).
- [ ] Functions have docstrings or JSDoc comments.
- [ ] Files are named descriptively.
- [ ] Code is broken into functions of manageable size (no 100-line main functions).

### Testing and Reliability
- [ ] Core functions have at least one unit test.
- [ ] Edge cases (empty input, zero, very long strings) are handled.
- [ ] The program does not crash on any typical user input.
