# Teacher's Guide: Python — Units 4–11

*(Continued from Part 1. See Part 1 for general principles and Units 0–3.)*

---

## UNIT 4: Data Structures — Lists and Dictionaries

### Lesson 4.1: More on Lists (Modifying)

#### Instructional Cues

- Reinforce the difference between methods that modify in-place vs. methods that return a new value. Students frequently confuse these:
  - `.append(x)` — modifies the list, returns `None`.
  - `sorted(lst)` — does NOT modify the list, returns a new sorted list.
  - `.sort()` — modifies the list in-place, returns `None`.
- A reliable demonstration: `result = my_list.append(42); print(result)` → `None`. Ask: "Where did the value go?" (Into the list. `.append()` doesn't return anything useful.)
- Introduce `.remove()` with the caution: it only removes the **first** occurrence. Ask: *"If your list is `[3, 7, 3, 9]` and you call `.remove(3)`, which 3 is removed?"* Always the first one.

#### Non-Obvious Accessibility Strategies

- **Checking the list after every modification:** Teach students to print the list after every operation during development. This is the audio equivalent of watching a visual debugger. `print(f"After append: {my_list}")` — develop this as a reflex.
- **The `ValueError` from `.remove()` when item isn't found:** This is a common crash. Teach the pattern of checking first: `if item in my_list: my_list.remove(item)`.

#### Thought Experiments

1. *"`.pop()` removes AND returns the last item. `.remove()` removes by value but returns nothing. When would you use each? What information are you prioritizing?"*
2. *"If `.append()` returns `None`, why does writing `my_list = my_list.append(x)` destroy your list? What does `None` assigned to `my_list` mean?"*
3. *"A list is ordered — items have positions. When you delete an item at index 2, what happens to the item that was at index 3? Does its index change?"*

---

### Lesson 4.2: Organizing Lists

#### Instructional Cues

- The `.sort()` vs. `sorted()` distinction is worth drilling: *"`.sort()` changes the patient (the list itself). `sorted()` creates a copy and sorts that — the original is unchanged."*
- Reverse-order sorting is a common need. Show both: `.sort(reverse=True)` and `sorted(lst, reverse=True)`.

#### Thought Experiments

1. *"Why might a program need both the original unsorted order AND a sorted order? What is a real-world example where maintaining the original order matters?"*
2. *"`sorted()` works on any iterable — lists, strings, even dictionaries. What would `sorted('hello')` produce? Predict it before trying."* (A sorted list of characters: `['e', 'h', 'l', 'l', 'o']`)

---

### Lesson 4.3: Tuples

#### Instructional Cues

- The key message: tuples are intentional immutability. Use this framing: *"When you use a tuple, you're making a promise: 'these values belong together and will never change.' This promise is enforced by the language."*
- Common use cases to discuss: coordinates (latitude, longitude), RGB color values, database records, function return values with multiple items.
- Show the `TypeError` that results from trying to modify a tuple. Read the error message together and confirm: this is Python enforcing the promise, not a bug.

#### Thought Experiments

1. *"If a tuple is just an immutable list, why have tuples at all? What would be lost if Python only had lists?"*
2. *"A function can only return one value. But `return 5, 10` returns a tuple — Python packs them together. How does this enable a function to effectively return multiple values?"*
3. *"Some data in the real world is inherently fixed: a birth date, a geographic coordinate, a chemical formula. What programming benefit comes from modeling this with a tuple rather than a list?"*

---

### Lesson 4.4: Introducing Dictionaries

#### Instructional Cues

- The mental model: *"A dictionary is a lookup table. You have a key — a label — and the dictionary tells you the corresponding value. Like a real dictionary: you look up 'serendipity' (key) and get its definition (value)."*
- Contrast with lists: "A list has numerical addresses (indices). A dictionary has named labels (keys). Both let you retrieve a value, but dictionaries let you use meaningful names."
- Demonstrate `KeyError` with a missing key: `student["major"]` where `"major"` doesn't exist → `KeyError`. Then show the safe alternative: `student.get("major", "Unknown")`.

#### Non-Obvious Accessibility Strategies

- **Printing dictionaries is verbose:** A raw `print(my_dict)` produces a long string that's hard to parse aurally. Teach the loop pattern from the start:
  ```python
  for key, value in my_dict.items():
      print(f"{key}: {value}")
  ```
  This is more accessible and also better practice.
- **Key naming conventions:** Keys should be strings that read naturally in speech. `"phone_number"` is better than `"ph"` when you're hearing `print(f"Phone: {contact['ph']}")`.

#### Thought Experiments

1. *"Dictionaries use keys to retrieve values. What properties must a key have to be useful? Why can you use a string or integer as a key, but not a list?"* (Lists are mutable — their "value" can change, making them unreliable as stable labels.)
2. *"A dictionary is an unordered collection in Python 2, but ordered in Python 3.7+. Why might order matter? What kinds of programs depend on the insertion order of keys?"*
3. *"Your contact list on a phone maps names to phone numbers. Model this as a Python dictionary. What happens if two contacts have the same name? How would you handle it?"*

---

### Lesson 4.5: Looping Through Dictionaries

#### Instructional Cues

- Three iteration modes: keys, values, items (pairs). Give a concrete use case for each:
  - Keys only: "List all the countries in the dictionary."
  - Values only: "Find the total inventory count."
  - Items: "Print a formatted report with both labels and values."

#### Thought Experiments

1. *"When you iterate over a dictionary, Python gives you the keys in insertion order. But other languages give them in random order. Why might the order of dictionary iteration matter, or not matter, depending on what you're doing?"*
2. *"Could you use a list of two-item tuples `[('name', 'Alice'), ('age', 15)]` instead of a dictionary? What would be easier? What would be harder?"*

---

## UNIT 5: User Input and `while` Loops

### Lesson 5.2: The `while` Loop

#### Instructional Cues

- The critical distinction to establish at the start: "`for` loops run a fixed number of times (once per item in a sequence). `while` loops run until something changes — they're for when you don't know in advance how many times you'll need to repeat."
- Demonstrate an infinite loop deliberately with a safe counter: set a maximum iteration count, show the loop running many times, then break out. Let the student experience `Ctrl+C` in the terminal to stop a runaway loop.
- Every `while` loop needs: (1) a condition that can become False, and (2) code that works toward making that condition False. Teach students to verify both before running.

#### Non-Obvious Accessibility Strategies

- **Detecting infinite loops:** A screen reader user may not notice that the program is "stuck" producing no new output if it's in an infinite loop with no `print()`. Teach the habit of including progress prints inside loops during development.
- **`Ctrl+C` is muscle memory:** Practice stopping a running program several times until pressing `Ctrl+C` becomes automatic. Infinite loops are inevitable; the escape is not always obvious.

#### Thought Experiments

1. *"A `while True:` loop runs forever unless you `break` out of it. Is this poor programming practice, a useful pattern, or both? When is `while True:` the clearest way to express intent?"*
2. *"Consider a program waiting for the user to type the correct password. Should this use a `for` loop with a limit, a `while` loop, or both? What are the security and usability tradeoffs?"*
3. *"The clock on your wall is running a `while` loop. Describe its condition, its body, and what would cause it to stop."*

---

### Lessons 5.3–5.5: Flags, `break`, `continue`, Infinite Loops

#### Thought Experiments

1. *"A `break` exits the loop immediately. A flag variable (`active = False`) causes the loop to exit at the top of the next iteration. When does the timing difference matter? Write a concrete example where the difference in timing changes the output."*
2. *"`continue` skips the rest of the current iteration. Why is this sometimes cleaner than wrapping the loop body in an `if` statement? When is the `if` version actually clearer?"*
3. *"Your program needs to read words from the user until they type 'quit.' Model this with both a flag variable and a `break` statement. Which do you prefer? Why?"*

---

## UNIT 6: Functions

### Lessons 6.1–6.5: Defining, Calling, Arguments, Returns

#### Instructional Cues

- Functions address a fundamental problem: repetition. Before introducing function syntax, demonstrate the problem: write the same 5 lines of code three times with slight variations. Ask: "What if you needed to change these 5 lines? You'd have to find and change all three copies. What could go wrong?"
- Then introduce functions as the solution: write it once, call it many times, change it in one place.
- The distinction between `print()` and `return` is one of the most persistent sources of beginner confusion. Establish the rule early: "`print()` is for humans. `return` is for the program. If you want to use the result later in your code, use `return`. If you just want to display it, use `print()`."

#### Non-Obvious Accessibility Strategies

- **Function docstrings are machine-readable comments:** Teach docstrings from the first function:
  ```python
  def add(a, b):
      """Returns the sum of a and b."""
      return a + b
  ```
  When the student uses IntelliSense in VS Code, the docstring appears in the hover tooltip — and via the Accessible View (`Shift+Alt+F2`), it's readable with a screen reader. Good docstrings are self-documentation that benefits the student's own future navigation.
- **Function names as audio navigation:** In a large file, a screen reader user navigates by searching or jumping. Well-named functions (`calculate_total_price()` vs. `func1()`) make it possible to navigate a file by searching for meaningful names. This is more important for blind students than for sighted ones who can visually scan.

#### Thought Experiments

1. *"A function is often described as a 'black box': you give it inputs, it gives you outputs, and you don't need to know the details inside. When is this abstraction helpful? When is it limiting?"*
2. *"Functions should do one thing. What does 'one thing' mean? Is `calculate_and_print_area()` one thing or two? Why does this distinction matter?"*
3. *"The `return` statement exits the function immediately. What happens if you have code after a `return` statement? Will it run? Is this ever useful?"*
4. *"In Python, a function with no `return` statement implicitly returns `None`. What does this tell you about how Python handles functions that are called for their side effects (like printing) vs. functions that are called for their return values?"*
5. *"Default parameter values (`def greet(name='World')`) allow a function to be called with or without arguments. How does this enable backward compatibility when you add a new parameter to an existing function?"*

---

## UNIT 7: Classes and Object-Oriented Programming

### Lessons 7.1–7.5: OOP Concepts Through Composition

#### Instructional Cues

- OOP is conceptually dense. Spend significant time on mental models before any code.
- The classic analogy: "A class is a cookie cutter. Objects are the cookies. The cookie cutter defines the shape; each cookie is an instance with that shape." Blind students may relate better to: "A class is a recipe. Objects are the dishes made from that recipe. The recipe defines what ingredients and steps are used; each dish is made from running the recipe."
- `self` is the hardest concept in early OOP. Explain: *"When you call `my_dog.sit()`, Python automatically passes `my_dog` as the first argument. Inside the `sit` method, that argument is named `self`. So `self.name` means 'the name of whichever dog this method was called on.'"*
- `__init__` is not a method you call — Python calls it for you. Demonstrate: `my_dog = Dog('Buddy', 3)` — you never write `my_dog.__init__('Buddy', 3)`. Python handles this automatically.

#### Non-Obvious Accessibility Strategies

- **toString equivalent (`__str__`):** Teach `__str__` early. When a student prints an object — `print(my_dog)` — they hear `<__main__.Dog object at 0x7f...>` which is meaningless. Teaching them to define `__str__` gives them control over what they hear:
  ```python
  def __str__(self):
      return f"Dog named {self.name}, age {self.age}"
  ```
  This is especially important for blind students who rely on printed output as their window into the program's state.
- **Navigating class files:** In larger class files, use `Ctrl+Shift+O` in VS Code to open the symbol picker, which lists all methods alphabetically. This allows jumping directly to a method by typing its name — screen reader accessible and much faster than scrolling through a file.

#### Thought Experiments

1. *"Why are instance variables stored as `self.name` rather than just `name`? What would happen if two different `Dog` objects stored their names in the same `name` variable?"*
2. *"Inheritance creates an 'is-a' relationship. A `Dog` is an `Animal`. When is this relationship appropriate? What goes wrong if you use inheritance for a 'has-a' relationship (e.g., a `Car` 'has an' `Engine`)?"*
3. *"Encapsulation means hiding internal details. In Python, there's no true `private` keyword — the underscore `_name` is a convention that says 'please don't access this directly.' Why might a language designer choose a convention over enforcement?"*
4. *"The `super()` function calls the parent class's method. Why is this necessary? What would happen if every subclass's `__init__` rewrote everything from scratch without calling `super()`?"*
5. *"Design a class called `AudioBook`. It needs attributes and methods appropriate for a book. Now design a subclass `ScholasticAudioBook` that adds chapter markers and reading speed. What does it inherit? What does it add? What does it override?"*

---

## UNIT 8: Files and Exceptions

### Lessons 8.1–8.5: I/O and Error Handling

#### Instructional Cues

- Files make programs persistent: *"Every program we've written so far forgets everything when it closes. Files are how programs remember things between runs."*
- The `with` statement: demonstrate what happens WITHOUT it first — a file is opened, an error occurs in the middle, and the file is never closed. Then show how `with` prevents this: the file closes automatically even if an error occurs.
- Exception handling philosophy: "Exceptions are not failures — they're messages. Python is telling you something unexpected happened. Your job is to decide what to do about it." Frame `try-except` as communication, not just error suppression.

#### Non-Obvious Accessibility Strategies

- **File paths are a common accessibility barrier:** Blind students often struggle with understanding where their files are located because they can't visually browse a file tree. Make `os.getcwd()` (current working directory) a standard diagnostic:
  ```python
  import os
  print(os.getcwd())
  ```
  Teach students to run this whenever they're unsure where their program is looking for files.
- **Relative vs. absolute paths:** Teach relative paths first (simplest) and establish the rule: "Your Python file and your data file should live in the same folder, and you should always run your Python file from that folder."

#### Thought Experiments

1. *"What happens if you open a file in `'w'` mode and the file already contains data? What about `'a'` mode? When would you use each?"*
2. *"Why should you always close a file after opening it? What could happen if you open 100 files without closing them? What does 'with open(...)' do to prevent this?"*
3. *"JSON is a text format for storing structured data. What are the advantages of text formats over binary formats? What are the disadvantages?"*
4. *"`try-except` lets you catch errors gracefully. What is the risk of using a bare `except:` that catches ALL exceptions? Why is it better to be specific with `except ValueError:` or `except FileNotFoundError:`?"*
5. *"Your program reads a configuration file on startup. What should happen if the file doesn't exist? If the file is corrupted? If the file contains unexpected values? Write out the ideal behavior in plain English before coding it."*

---

## UNIT 9: Testing and Data Analysis

### Lessons 9.1–9.5: Unit Testing and Data Processing

#### Instructional Cues

- Testing is often skipped in introductory courses. Frame it as protection: *"A test is a permanent record of 'this is what my program is supposed to do.' Every time you change your code, you run the tests to check you haven't broken anything. Tests are a safety net."*
- The `setUp()` method solves a specific problem: repeated setup code. Before showing `setUp()`, demonstrate the duplication problem — three test methods each creating the same object. Then show `setUp()` as the solution.

#### Non-Obvious Accessibility Strategies

- **Test output is especially important for blind students:** When tests run, they produce text output: dots for passes, `F` for failures, and detailed failure messages. This output is completely accessible with a screen reader. Testing is one area where the tooling is inherently accessible.
- **Testing as documentation:** Well-named tests serve as documentation of expected behavior. `test_calculate_area_with_zero_radius()` is more informative than `test_3()`. Encourage descriptive test names — both for clarity and for audio navigation.

#### Thought Experiments

1. *"What is the difference between testing and debugging? A test tells you THAT something is broken; debugging tells you WHY. Why is it useful to have both tools?"*
2. *"If you have 100% test coverage (tests cover every line of code), does that mean your program is correct? What kinds of bugs can tests miss?"*
3. *"A unit test tests one function in isolation. What do you do when a bug only appears when two functions work together? What kind of testing does that require?"*
4. *"Random numbers make testing difficult — if the output changes every time, how do you test it? What strategies exist for testing programs that use randomness?"*

---

## UNIT 10: Project-Based Learning

### Lessons 10.1–10.5: Building Text-Based Applications

#### Instructional Cues

- This unit is about sustained independent work. Your role shifts from instructor to mentor. The primary instructional move is to ask questions rather than give answers.
- Before any code is written: require a written design document. For blind students who may not sketch on paper, a structured text file works well:
  ```
  Project: Contact Manager
  Features: add contact, view all, search, delete, save, load
  Data structure: list of dictionaries
  Attributes: name, phone, email, notes
  Main loop: show menu → take input → call function → repeat
  ```
- Teach the concept of **iterative development**: build the smallest working version first, test it, then add one feature at a time. Never try to build everything at once.

#### Non-Obvious Accessibility Strategies

- **Menu design for screen readers:** Text-based menus that print options and accept single-character inputs are highly accessible. Number options clearly. Confirm the user's choice before executing: `print(f"You selected: Add contact")`.
- **Progress feedback:** Every operation should produce a message. Never let an action succeed silently. `print("Contact added successfully.")`, `print("No contacts found.")`, `print("File saved.")` — these messages are the screen reader user's confirmation that something happened.
- **Error vs. not-found vs. invalid input:** Teach students to distinguish three types of messages:
  - "Invalid input: please enter a number between 1 and 4."
  - "Contact not found: no contact named 'Alice' exists."
  - "Error: could not save file. Check that you have write permissions."
  Each has a different cause and a different appropriate response.

#### Thought Experiments

1. *"Top-down design breaks a large problem into smaller parts. What is the risk of decomposing too early? How do you know when a sub-problem is 'small enough' to code directly?"*
2. *"Your contact manager has a `search_contact()` function. What inputs should it accept? What should it return? What should it do if no match is found? If there are multiple matches?"*
3. *"A program designed for sighted users often uses visual cues to organize information: columns, color coding, different font sizes. How would you replace each of these with audio-friendly alternatives in a terminal program?"*

---

## UNIT 11: Capstone Project

### Assessment Guidance for Teachers

#### Process Checkpoints (Recommended)

Rather than assessing only the final product, use these intermediate checkpoints:

| Checkpoint | Timing | What to Evaluate |
|------------|--------|-----------------|
| Design document | Before any code | Are features realistic? Is data structure appropriate? |
| Core data model | After first week | Can items be created and stored in memory? |
| Basic CRUD | After second week | Can items be added, viewed, and deleted? |
| Persistence | Third week | Does data survive between runs? |
| Error handling | Fourth week | Does the program handle invalid input gracefully? |
| Final demo | End | Full demonstration using screen reader |

#### The Screen Reader Demo

The final demonstration should be conducted entirely with the screen reader active. The student should:
1. Start the program.
2. Navigate to the "Add Item" option by listening to the menu.
3. Add an item, entering all fields in response to prompts.
4. Navigate to "View All Items" and hear the item listed.
5. Edit the item.
6. Delete the item.
7. Save data and quit.
8. Restart the program and load saved data.

This demonstrates that the program is genuinely accessible, not just functional.

#### Thought Experiments for Capstone Reflection

1. *"You've built a program that another blind user might use. What did you learn about designing for your own access needs? What surprised you?"*
2. *"What is the difference between a program that works and a program that is accessible? Can a program work without being accessible?"*
3. *"If you were going to continue developing this program for a year, what features would you add? What would you refactor? What would you test more thoroughly?"*
4. *"Git allows you to undo changes and see the history of a project. How would having Git affected your development process? What moments during the project would have been better with version control?"*

---

## Supplemental: AI Tools in This Course

### Teacher Guidance on AI Code Tools

This curriculum includes a lesson on AI coding tools (GitHub Copilot, Claude, ChatGPT, etc.). The pedagogical position is: **use AI as a learning amplifier, not a homework machine.**

#### How to Frame AI for Blind Students

For a blind student, AI tools have a unique profile of benefits and risks:

**Potential benefits:**
- AI can generate boilerplate code quickly, freeing cognitive bandwidth for the interesting logic.
- AI can explain error messages in plain English, which is often faster than deciphering documentation.
- AI can generate multiple versions of the same function, giving the student examples to reason about.

**Potential risks:**
- AI-generated code may not be accessible — it might produce programs with poorly labeled output, missing error messages, or confusing prompts.
- AI may generate plausible-looking code that is subtly wrong, and a student who cannot visually scan the code may accept it without scrutiny.
- Over-reliance prevents the student from developing the independent debugging skills that are essential for professional work.

#### Suggested AI Usage Policy

*"You may use AI tools to help you understand concepts, generate starting code for exploration, or explain error messages. You may not use AI to complete any assignment without reading, understanding, and being able to explain every line of the generated code. When in doubt: ask yourself whether you could write this code again from scratch. If not, you haven't learned it yet."*

#### Thought Experiments About AI

1. *"An AI generates code for you. You run it and it works. Have you solved the problem? What have you actually learned?"*
2. *"If AI can write most code, what skills become MORE valuable for programmers? What do you think humans will always need to contribute?"*
3. *"AI tools are trained on code written by sighted programmers. What accessibility-related blind spots might they have? Can you think of a case where an AI would suggest code that works but is inaccessible?"*

---

## Quick Reference: Accessible Teaching Techniques by Concept

| Concept | Accessible Approach |
|---------|-------------------|
| Variables | "Labeled boxes" metaphor; use `type()` constantly |
| Indentation | Configure screen reader beeps/announce; use block-marker comments early |
| Loops | Narrate iteration aloud; print inside loops to trace |
| Lists | Print elements one-per-line, not raw list; use `enumerate()` |
| Dictionaries | Print with `for key, value in d.items()` always |
| Functions | Name descriptively; write docstrings; use `return` not `print` |
| Classes | Define `__str__`; navigate with symbol picker `Ctrl+Shift+O` |
| Files | Use `os.getcwd()` to confirm location; use relative paths |
| Errors | Read from bottom up; use `F8` for navigation |
| Testing | Print test names; use descriptive method names |
| Debugging | `print()` statements at every decision point; verbally trace code |
