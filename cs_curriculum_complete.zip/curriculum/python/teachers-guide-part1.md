# Teacher's Guide: Introduction to Computer Science with Python
## For Visually Impaired Students

---

## How to Use This Guide

Each section follows the student curriculum unit-by-unit. For every lesson you will find:

- **Instructional Cues** — Specific language, pacing suggestions, and techniques for delivering the material without relying on visual demonstration.
- **Non-Obvious Accessibility Strategies** — Approaches that sighted teachers may not think of but that make a meaningful difference for screen reader users.
- **Thought Experiments** — Open-ended questions that build conceptual understanding without requiring any code.
- **Common Pitfalls** — Mistakes that are especially likely for students who cannot see their screen.
- **Alternative Explanations** — Multiple framings of the same concept; use whichever lands best for a given student.
- **Additional Resources** — Accessible external materials.

---

## General Principles Before You Begin

### On Speaking About Code

When demonstrating code verbally or describing it over a call, develop a consistent spoken vocabulary for symbols. Suggested conventions:

| Symbol | Say |
|--------|-----|
| `=` | "gets" or "is assigned" |
| `==` | "is equal to" |
| `!=` | "is not equal to" |
| `>=` | "is greater than or equal to" |
| `()` | "open paren … close paren" |
| `[]` | "open bracket … close bracket" |
| `{}` | "open brace … close brace" |
| `:` | "colon" |
| `"hello"` | "quote hello quote" |
| `f"..."` | "f-string" |
| `#` | "hash" or "comment" |
| `\n` | "backslash n" or "newline" |
| `_` | "underscore" |

Consistency matters far more than the exact words you choose. Establish these conventions on day one and stick to them throughout the course.

### On Indentation (Python-Specific Critical Issue)

Python's indentation is not just stylistic — it is syntactic. For a student who cannot see the visual alignment of code, this is the single greatest source of confusion. Address it explicitly and frequently.

**Techniques:**
- Configure the student's screen reader to announce indentation using tones or the word "indent." NVDA: NVDA+N → Preferences → Settings → Document Formatting → Indentation → "Say all." JAWS: Check the "Text Processing" settings for pitch changes on indent. VoiceOver: Verbosity settings.
- Teach the student to navigate line-by-line using arrow keys and listen for the indent announcement before listening to the code on that line.
- Use the verbal convention: "everything that is indented under this line belongs to this block."
- Consider adding block-marker comments for very long or nested blocks during early lessons: `# --- start if block ---` and `# --- end if block ---`. This is scaffolding to be removed later.

### On Error Messages

Error messages are the student's primary debugging tool. Unlike a sighted student who can scan the screen, a screen reader user must navigate deliberately to error output. Teach this workflow from the very first error:

1. The error appears in the terminal after the code that produced it.
2. Read from the bottom of the error output upward — the most relevant line is usually last.
3. The line number in the traceback tells you exactly where to look. Use `Ctrl+G` in VS Code to jump to that line.
4. Read the error type first (e.g., `SyntaxError`, `NameError`) — this is a category that narrows the search.
5. Read the error message — this is the description.

Spend time on error messages early. Make it a game: produce a known error deliberately, then walk through the reading process together.

---

## UNIT 0: Setting Up Your Accessible Python Development Environment

### Lesson 0.1: Installing Python and VS Code

#### Instructional Cues

- This lesson involves navigating websites and running installers. Walk through it synchronously with the student if at all possible — installation is a point where irreversible mistakes happen.
- Before starting, confirm the student's screen reader is running and they can navigate a browser. Do not assume.
- When asking them to check a checkbox, describe its location relative to other elements they can tab to: "The 'Add Python to PATH' checkbox appears near the bottom of the first installer screen, before the Install Now button. Tab through until you hear it announced."
- After installation, script the verification steps: open terminal → type command → listen for output. Do not move forward until verification succeeds.

#### Non-Obvious Accessibility Strategies

- **Avoid the Windows Store Python.** The Store version installs in a different location and often causes PATH confusion. Always use python.org.
- **Command prompt vs. PowerShell:** For beginners using NVDA or JAWS, Command Prompt (`cmd`) may read more reliably than PowerShell. Both work; know which one your student's screen reader handles better.
- **macOS Terminal vs. iTerm2:** Standard Terminal works well with VoiceOver. If the student wants more features, iTerm2 also has good accessibility.
- **Aliasing on macOS:** On newer Macs, `python` may point nowhere. Always use `python3` and `pip3` explicitly in instructions.

#### Thought Experiments

1. *"Before we install anything — why do you think the Python installer has a checkbox called 'Add Python to PATH'? What is a PATH, and what would happen if Python weren't on it?"* (Let them reason about it. The answer: the operating system wouldn't know where to look for Python when you type `python3` in a terminal.)
2. *"We're installing two things: Python and VS Code. What role does each one play? If you had only Python and no VS Code, could you still write programs?"* (Yes — the terminal and any text editor would work. VS Code is a productivity enhancement, not a requirement.)
3. *"Why do we verify the installation after completing it? What could go wrong between downloading and confirming it works?"*

#### Common Pitfalls

- Student installs Python but forgets the PATH checkbox → `python3` not found in terminal. Fix: reinstall and check the box, or manually add to PATH.
- Student has both Python 2 and Python 3 installed → `python` runs Python 2. Always use `python3`.
- Student installs VS Code but cannot find it afterward. Teach them: `code --version` in terminal, or search their applications list.

---

### Lesson 0.2: Configuring Your Screen Reader for VS Code

#### Instructional Cues

- Begin this lesson by asking the student to open VS Code and navigate it with only their keyboard and screen reader. Do NOT guide them through it immediately. Let them explore for 5–10 minutes and report what they discover. This builds genuine familiarity.
- Then introduce each accessibility feature as a solution to something they encountered: "You mentioned you couldn't easily find where errors were — that's what F8 is for."
- Physically demonstrate (or verbally walk through) the NVDA/JAWS/VoiceOver indentation configuration immediately. Do not defer this — it must be working before any Python is written.

#### Non-Obvious Accessibility Strategies

- **Beeps vs. "Say All" for indentation:** "Say All" announces the number of spaces (e.g., "4 spaces"). Beeps use pitch to signal depth. Students with musical training often prefer beeps because they process pitch change faster than words. Students without musical training usually prefer "Say All." Ask the student which they want to try.
- **The Accessible View is underused:** `Shift+Alt+F2` opens a flat text representation of hover content and error panels. This is especially useful when IntelliSense suggestions pop up — the student can press this key to hear the full suggestion text without the popup disappearing.
- **Column number matters:** Teach students to listen to the status bar's column number when debugging syntax errors. A missing parenthesis at column 20 is much easier to find with that information.
- **"Go to Line" is essential:** `Ctrl+G` → type line number → Enter. Make this a reflex, not an afterthought.
- **Turning off animations:** Some screen readers interact poorly with VS Code's animation effects. In VS Code settings, search "workbench.reduceMotion" and set it to "on."

#### Thought Experiments

1. *"Imagine you're writing code in a dark room with no monitor. What information would you most need to know about your code file to navigate it effectively?"* (This surfaces the importance of line numbers, column position, indentation levels, and the file structure.)
2. *"A sighted programmer can glance at a block of code and immediately know 'this belongs to the if statement' by looking at the indentation. How does your screen reader give you the same information, and is it faster or slower?"*
3. *"When a sighted person misses a closing parenthesis on line 5 and runs the program on line 20, their eye might jump to line 5 quickly. Walk me through how you'd find the same error using only your screen reader."*

---

### Lesson 0.3: Setting Up Your VS Code Workspace

#### Instructional Cues

- The concept of a "workspace folder" can be unclear to students who have not worked with file systems independently. Use this framing: "A workspace folder is like a dedicated desk for one project. When you open VS Code pointing to that desk, it knows every file in your project is related."
- Walk through creating the folder via the terminal (`mkdir`) rather than the file manager GUI. This is more accessible and reinforces terminal skills: `mkdir ~/Documents/PythonProjects`.
- Extensions: navigate the Extensions panel together on the first install. After that, expect the student to do it independently.

#### Non-Obvious Accessibility Strategies

- **The Explorer tree requires specific navigation habits:** In the Explorer (`Ctrl+Shift+E`), use arrow keys to move through files. `Enter` opens a file. `F2` renames. Teaching these early prevents mouse dependence.
- **Naming conventions matter more for screen reader users:** A file named `u3l2_loops.py` is harder to hear quickly than `lesson_3_loops.py`. Encourage descriptive, speech-friendly filenames from day one.
- **Multiple files open at once:** Teach the student to use `Ctrl+Tab` to switch between open editor tabs and to close tabs they're done with (`Ctrl+W`). Tab clutter is harder to manage without visual reference.

#### Thought Experiments

1. *"Why do programmers organize code into folders by project instead of putting everything in one place?"* (Connect to real-world analogy: imagine if every book in a library was on one giant pile rather than organized by subject.)
2. *"VS Code extensions add features to the editor. What extensions might a sighted programmer want that would be useless for you? What accessibility-specific features might you want that a sighted user would never think to install?"*

---

### Lesson 0.4: Python Environments and Terminal Usage

#### Instructional Cues

- The terminal is the student's most important tool. Invest heavily in comfort here before moving to code.
- Teach the terminal as a conversation: "You type a command, press Enter, the computer responds, then waits for your next command." Have the student practice `ls` (or `dir` on Windows), `cd`, `pwd`, and `python3 --version` before anything else.
- Virtual environments are conceptually challenging. Use this analogy before showing commands: *"Imagine you have two science projects. One needs distilled water, one needs saltwater. If you only had one beaker, mixing experiments could ruin both. A virtual environment is a separate beaker for each project's ingredients."*

#### Non-Obvious Accessibility Strategies

- **Terminal output scrollback:** Terminal output may be long. Teach the student to use `Shift+Page Up` / `Shift+Page Down` to scroll back through output. In VS Code's integrated terminal, the screen reader can typically read previous output.
- **Clearing the terminal:** `clear` (macOS/Linux) or `cls` (Windows) removes previous output, which can be helpful when the terminal becomes cluttered with old error messages.
- **Arrow keys for command history:** Up and Down arrow keys cycle through previous commands in the terminal. This is more efficient than retyping and works in all shells.
- **Tab completion in the terminal:** Pressing Tab auto-completes filenames and commands. Teach this early — it reduces typos and the cognitive load of remembering exact filenames.

#### Thought Experiments

1. *"Why do we need a separate virtual environment for each project? What could go wrong if we installed all packages globally?"*
2. *"When you type `python3 hello.py` in the terminal, what is actually happening behind the scenes? What is Python 'doing' with that file?"*
3. *"Pip installs packages written by other people. What are the advantages and risks of using other people's code in your program?"*

---

## UNIT 1: Foundations — Computing and Getting Started with Python

### Lesson 1.1: Welcome to Computer Science

#### Instructional Cues

- Open with the "Human Computer" role-play activity. This is especially effective for blind students because it makes explicit the precision required of instructions — precision that sighted people often take for granted when they can watch someone try to follow the instructions and self-correct visually.
- When discussing hardware vs. software, use tactile analogies where possible. Students who are congenitally blind may have limited visual reference for "a monitor" or "a keyboard." Ask what technology they personally use and build from there.
- Discuss the screen reader itself as an example of software: *"What hardware does your screen reader run on? What input does it read? What output does it produce?"*

#### Non-Obvious Accessibility Strategies

- **Blind students often have sophisticated mental models of computers** from years of audio-based interaction. Do not assume they lack understanding of technology — they may have deeper conceptual knowledge than sighted peers.
- **Use audio metaphors:** Describing a CPU as "the brain that processes one thought at a time very quickly" works well. Describing RAM as "short-term memory, like what you're thinking about right now" and storage as "long-term memory, like what you'd look up in a book" translates well across modalities.

#### Thought Experiments

1. *"A program is a set of instructions for a computer. But a recipe is also a set of instructions for a person. What makes programming instructions different from a recipe? What rules does a computer follow that a person doesn't?"*
2. *"Your screen reader is a program. What is its input? What is its output? Who tells it what to do?"*
3. *"If you could design a programming language specifically for blind programmers, what would you change about Python? What would you keep the same?"*
4. *"Early computers filled entire rooms and could only do arithmetic. Smartphones fit in a pocket and can play music, navigate streets, and read text aloud. What changed? Was it the hardware, the software, or both?"*

---

### Lesson 1.2: Your First Python Program — "Hello World!"

#### Instructional Cues

- Before typing anything, ask the student to predict: *"If I write `print("Hello, World!")`, what do you think will happen when we run it? Where will the output appear?"*
- After running the program, ask them to navigate the terminal with their screen reader and locate the output. Do not point it out. This builds independent navigation skills.
- Introduce the concept of a **syntax error** by deliberately creating one: remove the closing parenthesis, run the program, and then walk through reading the error message. Frame this positively: "Syntax errors are the computer telling you exactly where it got confused. They're helpful."

#### Non-Obvious Accessibility Strategies

- **Reading code aloud practice:** Have students read their code line by line using the screen reader, then describe what each line does in plain English before running it. This builds the habit of mentally simulating code execution — which is the core skill of debugging.
- **Multiple `print()` statements as landmarks:** For a student who cannot scan a file visually, multiple well-labeled print statements (e.g., `print("--- Starting calculation ---")`) can serve as audio landmarks during program execution. Encourage this habit from the start.

#### Thought Experiments

1. *"`print()` is a function — a built-in tool that Python provides. What would happen if Python didn't have `print()`? How would you know if your program was doing the right thing?"*
2. *"When you run a Python file, Python reads your instructions from top to bottom, one line at a time. What happens if line 3 has an error? Does Python run lines 1 and 2 first, or does it stop immediately?"* (Python compiles first, so a SyntaxError on line 3 prevents any lines from running; a RuntimeError on line 3 means lines 1 and 2 ran first. This distinction matters.)
3. *"'Hello, World!' is the traditional first program in almost every programming language. Why do you think that tradition exists? What does this simple program actually prove?"*

---

### Lesson 1.3: Variables and Simple Data Types

#### Instructional Cues

- Introduce variables with a physical metaphor: *"A variable is like a labeled box. The label is the variable name. The contents of the box are the value. When Python sees the name `score`, it goes to that box and retrieves whatever's inside."*
- Naming rules are hard to remember in the abstract. Walk through them with examples: "Let's try some names and you tell me if they're valid." Then test: `first_name` (valid), `2nd_number` (invalid — hear what Python says), `my-score` (invalid — hyphens not allowed), `for` (invalid — reserved word).
- The `type()` function is a powerful diagnostic tool. Introduce it early: `print(type(42))` → `<class 'int'>`. Teach students to use it whenever they're unsure what kind of data they have.

#### Non-Obvious Accessibility Strategies

- **String vs. number confusion is auditorily subtle:** When a screen reader announces `"42"` and `42`, they sound identical. This is a significant challenge. Explicitly teach: the difference between `"42"` (a string) and `42` (an integer) only appears when you try to do math. Use `type()` liberally.
- **f-string pronunciation:** Some screen readers mispronounce `f"..."` or skip the `f` prefix entirely. Teach students to explicitly read the first character of a string literal to check whether it's an f-string. `f` before the quote means "formatted string" — any `{variable}` inside will be replaced.
- **CamelCase vs. snake_case:** Python convention is `snake_case` (underscores between words). For a screen reader user, `firstName` is read as "firstname" (one word) by some readers; `first_name` may be read as "first underscore name" or "first name" depending on settings. Either works, but snake_case is conventional Python and often reads more clearly.

#### Thought Experiments

1. *"If variables are labeled boxes, what happens when you do `x = 5` and then `y = x`? Do `x` and `y` share the same box, or do they each have their own?"*
2. *"Python is 'dynamically typed,' meaning a variable can hold any type of data. What are the advantages of this? What could go wrong if a variable that's supposed to hold a number accidentally holds a string?"*
3. *"Why can't variable names start with numbers? What would happen if `2fast = 10` were legal? How would Python know the difference between the number `2` and the start of a variable name?"*
4. *"What would happen if Python had no integers, only floats? Could you still write a program that counts apples? What problems might arise?"*

---

## UNIT 2: Writing Simple Programs and Numeric Computations

### Lesson 2.1: The Software Development Process

#### Instructional Cues

- This is a conceptual lesson with no code. Use it as a genuine design workshop. Give the student a real problem to solve (e.g., "Write a program that asks for a person's birth year and tells them how old they are") and guide them through pseudocode before any Python is written.
- When reviewing pseudocode, read it back to the student and ask: "Does this make sense as instructions? Is anything missing? What assumptions are we making?"

#### Non-Obvious Accessibility Strategies

- **Pseudocode is especially valuable for screen reader users** because it lets them plan without worrying about syntax. Encourage writing pseudocode in a plain `.txt` file that the screen reader can navigate freely.
- **"Rubber duck debugging" goes both ways:** Blind students cannot stare at code for typos, but they can think through logic by speaking it aloud. Encourage narration: "First my program does X, then Y, then Z." This surfaces logical errors before they reach code.

#### Thought Experiments

1. *"A professional architect draws blueprints before construction begins. Why? What's the cost of changing a blueprint vs. changing a half-built wall? How does this apply to software?"*
2. *"The design phase involves thinking about edge cases — unusual inputs. For a program that divides two numbers, what edge case immediately comes to mind? What should the program do if the user enters zero as the denominator?"*
3. *"Some programmers skip the design phase and just start coding. What are the risks? Can you think of a situation where skipping design might be reasonable?"*

---

### Lesson 2.2: Expressions and Assignment

#### Instructional Cues

- Draw the distinction between "storing a value" (assignment with `=`) and "comparing two values" (equality check with `==`) on day one. This confusion causes more bugs than almost any other single issue.
- Demonstrate the order of operations verbally: "Say this expression aloud: `10 + 5 * 2`. Most people would say the answer is 30, but Python says 20. Why?" Let the student reason through PEMDAS.

#### Thought Experiments

1. *"In math, `x = 5` is a statement of fact: x equals 5. In Python, `x = 5` is a command: 'store 5 in x.' Why is this difference important? What would happen if Python treated `x = 5` as a fact rather than a command?"*
2. *"What does `score = score + 10` mean? How can something equal itself plus something else? In what sense is the `=` here not the same as the `=` in math?"*

---

### Lesson 2.3: Input and Output

#### Instructional Cues

- Before introducing `input()`, ask: *"Right now our programs always use the same numbers. What would make a program more useful?"* Guide the student to say "if it could ask the user for numbers."
- Emphasize with concrete demonstration: write a program that asks for a name, store it in a variable, then print it. Ask: *"What happens if the user types a number when asked for their name? Does the program care?"* No — it's just a string.
- The critical insight — `input()` always returns a string — must be demonstrated with a deliberate failure. Write a program that asks for a number, does NOT convert it, and tries to add 1. Let the student encounter the `TypeError` and read the error message.

#### Non-Obvious Accessibility Strategies

- **Prompt text is critical for screen reader users:** When a blind user encounters an `input()` prompt, the prompt message is the only information they have about what to type. Demand descriptive prompts from the very first exercise. "Enter number: " is insufficient. "Enter your age in years (whole number): " is better.
- **Trailing space in prompts:** Always include a space after the colon in prompt strings: `input("Enter name: ")` — without the space, the cursor appears immediately after the colon with no audio separation, which some screen readers render as "Enter name:cursor."

#### Thought Experiments

1. *"Why does `input()` always return a string, even when the user types `42`? What would be the risks if Python guessed the type based on what the user typed?"*
2. *"Imagine you're designing a program for the visually impaired to fill out a form. What information would you include in each `input()` prompt? What information would be obvious to a sighted user looking at a form that might not be obvious to someone using a screen reader?"*
3. *"If a user types 'five' when your program expects the number 5, what should happen? Is it the user's fault, the programmer's fault, or neither?"*

---

### Lesson 2.4: Type Conversions

#### Instructional Cues

- Demonstrate all four key conversions with the same value: `"42"` → `int("42")`, `"42"` → `float("42")`, `42` → `str(42)`, `42.9` → `int(42.9)`. Ask after each: "What is the type now? What was lost or gained?"
- The truncation behavior of `int()` is often surprising: `int(4.9)` is `4`, not `5`. Ask: *"Is `int()` rounding, or doing something different? What word describes what it's doing?"* (Truncating — removing the decimal part, not rounding.)

#### Thought Experiments

1. *"If you call `int('hello')`, Python raises a `ValueError`. This is a kind of error you'll need to handle. Who is responsible — the programmer for not converting, or the user for not entering a number? How would you handle both possibilities?"*
2. *"In everyday life, when do you 'convert' information from one form to another? Describe the conversion process and what might be lost."* (Examples: currency conversion loses precision; rounding a measurement to the nearest inch loses information.)

---

### Lesson 2.5: The Math Library

#### Instructional Cues

- Before `import math`, ask: *"What if you need to calculate a square root? Could you write your own code to do that?"* Acknowledge yes, but it would be hard. Modules are other people's solutions to problems we'd otherwise have to solve ourselves.
- Demonstrate dot notation: `math.sqrt(25)`. Explain: "The dot means 'look inside the `math` module for something called `sqrt`.' The module is the namespace — the container."

#### Thought Experiments

1. *"Python's math module has functions like `math.sin()` and `math.cos()`. Even if you never use trigonometry in your programs, why is it useful that these exist in the standard library?"*
2. *"`math.pi` is stored as `3.141592653589793`. Real pi has infinite digits. What are the implications of using an approximation in a calculation? When would this matter, and when wouldn't it?"*
3. *"Why do you think `math.sqrt(25)` returns `5.0` (a float) rather than `5` (an integer), even though the answer is a whole number?"*

---

## UNIT 3: Control Flow — Decisions and Loops

### Lesson 3.1: Boolean Expressions and `if` Statements

#### Instructional Cues

- Introduce Boolean values as the simplest possible data: only two options. *"Every decision a computer makes reduces to True or False. It cannot feel uncertainty, it cannot say 'maybe.' Every if statement is Python asking a yes/no question."*
- Indentation is now mission-critical. Before writing any `if` statement, explicitly state: *"Everything indented under the `if` line belongs to that block. When the indentation goes back to the original level, we're outside the block. Your screen reader will announce this."*
- Demonstrate the assignment-vs-comparison mistake deliberately: `if age = 18:` → `SyntaxError`. Read the error together. Then fix it: `if age == 18:`. Ask: *"What would have happened if Python let you write `if age = 18:` without an error? What would it mean?"*

#### Non-Obvious Accessibility Strategies

- **Mentally simulating if statements:** Teach students to substitute actual values before asking whether the code is correct. "If `age` is 15, then `age >= 18` is... 15 >= 18... False. So the if block does NOT run."
- **Verbally tracing code:** Encourage students to narrate execution aloud: "Python checks: is score greater than or equal to 90? Score is 85. 85 is not greater than or equal to 90. False. So Python skips the if block and checks the elif..."

#### Thought Experiments

1. *"If Python didn't have `if` statements, what would programming be like? Can you think of a program that doesn't need any decisions?"*
2. *"Consider: `if True:` — this is legal Python. The block always runs. `if False:` — the block never runs. When would these ever be useful?"*
3. *"Computers make millions of True/False decisions per second. In what sense is all computing just Boolean logic? Can you trace a single decision — like 'play the next audio track' — back to True/False questions?"*
4. *"The `=` in math means 'these two things are equal.' Python uses `==` for comparison and `=` for assignment. Some languages use `:=` for assignment. Why did these distinctions arise? What confusion would exist without them?"*

---

### Lesson 3.2: Chained Conditionals

#### Instructional Cues

- The ordering of `elif` chains is a subtle source of bugs. Demonstrate with grade checking: if you put `elif score >= 70` before `elif score >= 90`, a score of 95 gets "C" instead of "A." Ask: *"Why does order matter here? If both conditions are True for score=95, which one does Python use?"*
- Teach the "as soon as" rule: "Python checks conditions in order, and as soon as one is True, it runs that block and skips all the remaining elifs and else."

#### Non-Obvious Accessibility Strategies

- **Audio tracing of elif chains:** Have students read each branch aloud with a specific value substituted. "For score=75: is 75 >= 90? No. Is 75 >= 80? No. Is 75 >= 70? Yes. So we get C." Doing this verbally builds confidence and catches ordering errors.

#### Thought Experiments

1. *"An `if-elif-else` chain guarantees exactly one branch runs. Why is this useful? Can you think of a scenario where you'd want zero branches to run, or more than one?"*
2. *"Logically, `else` means 'in every other case.' What is the programmer asserting when they write `else: print('Invalid input')`? What assumption about all possible inputs does this make?"*
3. *"In English, we say 'if it's raining bring an umbrella, otherwise bring sunscreen.' Convert this to an if-else in Python. Are there edge cases the English statement doesn't handle that Python forces you to consider?"*

---

### Lesson 3.3: Introduction to Lists

#### Instructional Cues

- Lists are abstract without a mental model. Offer several framings and let the student choose the one that resonates:
  - *A numbered storage unit with many rooms, each room having an address starting at 0.*
  - *A train: each car is a compartment (element), and the car numbers start at 0 at the front.*
  - *A playlist: each song is an item, ordered from 0.*
- Zero-based indexing is consistently surprising. Say: *"In everyday life we start counting at 1. Python starts at 0. The first item is at position 0, the second at position 1. This will feel wrong for a while. That's normal."*
- Negative indexing is genuinely elegant for students who grasp it: `list[-1]` is always the last element, no matter how long the list is.

#### Non-Obvious Accessibility Strategies

- **Printing lists for audio consumption:** A plain `print(my_list)` produces `['apple', 'banana', 'cherry']` — the brackets and quotes clutter the audio reading. For accessibility, looping and printing each element on its own line is often cleaner:
  ```python
  for i, item in enumerate(fruits):
      print(f"{i}: {item}")
  ```
  Teach this pattern early and explain why it's often more accessible than printing the raw list.
- **List length as a safety check:** Before accessing an index, always know the length. Teach `len()` as a protective habit.

#### Thought Experiments

1. *"Why do you think Python (and most programming languages) start list indices at 0 instead of 1? What mathematical advantage does this provide?"*
2. *"A list allows duplicate values: `['cat', 'dog', 'cat']`. When would duplicate values in a list be meaningful? When would they indicate an error?"*
3. *"If lists didn't exist, how would you store 100 student names in Python? What would be the problem with your approach?"*

---

### Lesson 3.4: `for` Loops

#### Instructional Cues

- The conceptual leap is "automatic repetition." Start with: *"What if I asked you to print every item in a 100-item list? Writing 100 `print()` statements is not acceptable. A loop tells Python to repeat an action automatically."*
- Trace the first loop together, line by line: "Python picks up the first item in the list, assigns it to `fruit`, runs the indented block, then goes back to the top, picks up the second item, assigns it to `fruit`, runs the block again..."
- `range()` is a function that generates a sequence of numbers on demand. It's not a list, but it works like one in a `for` loop. Clarify: `range(5)` produces `0, 1, 2, 3, 4` — five numbers, starting at 0, not including 5.

#### Non-Obvious Accessibility Strategies

- **Trace output is a debugging superpower:** Encourage students to add `print()` statements inside loops to hear each iteration's value. This is basic debugging but is especially important when you can't watch a visualizer.
- **Loop counter mental model:** For very concrete thinkers, the for-loop can be described as: "Imagine Python has a bookmark. It starts at position 0 in the list. It runs the loop body, moves the bookmark to position 1, runs the loop body again, moves to position 2... and stops when the bookmark falls off the end."

#### Thought Experiments

1. *"A `for` loop with a list runs once for each item. A `for` loop with `range(100)` runs 100 times. What is the difference between these conceptually? When would you use each?"*
2. *"Can you think of something in daily life that works like a `for` loop? An activity that repeats with a slight variation each time?"*
3. *"What happens if you iterate over an empty list: `for item in []:`? Does Python crash? Does it print an error? Does it simply do nothing?"* (It does nothing — this is correct behavior and worth understanding.)

---

### Lesson 3.5: Basic String Operations

#### Instructional Cues

- Reinforce: strings are immutable. `"hello".upper()` does NOT change `"hello"` — it creates a new string. This is subtle and breaks many beginner programs. Demonstrate: `text = "hello"; text.upper(); print(text)` — the print still shows `"hello"`. Ask: *"What went wrong? How do we fix it?"* (`text = text.upper()`)
- Introduce `.split()` as the inverse of concatenation: strings apart → list of strings. Introduce `.join()` as the inverse of `.split()`: list of strings → one string. Show both directions.

#### Thought Experiments

1. *"Strings are immutable — they cannot be changed, only replaced. Why would a language designer choose immutability for strings? What bugs does this prevent?"*
2. *"`'hello world'.split()` returns `['hello', 'world']`. What does `'hello,world'.split(',')` return? What about `'hello,,world'.split(',')`? Predict before running."*
3. *"If you were designing a text editor for a screen reader user, how would you use string operations to implement a 'find and replace' feature?"*

---

## Additional Resources for Units 0–3

### For Students

- **Python Tutor (pythonictutor.com):** Step-by-step code execution visualizer — while primarily visual, the text output panel is accessible and shows variable state at each step.
- **Python docs (docs.python.org/3/):** The official documentation is plain HTML, highly accessible to screen readers. Bookmark the "Built-in Functions" page.
- **APH Tech Connections:** The American Printing House for the Blind maintains resources specifically for teaching computing to blind students at techconnections.org.

### For Teachers

- **CSUN Assistive Technology Conference proceedings:** Annual research on accessible computing education. Many papers address programming instruction for blind students.
- **Teaching Kids to Code (accessibility section):** O'Reilly's guide has a chapter on adaptive techniques.
- **Hadley Institute for the Blind:** Offers professional development for educators working with visually impaired students in technology contexts.

### Professional Communities

- **NFB (National Federation of the Blind) Science and Engineering Division:** Active community of blind scientists and engineers who were once blind students.
- **ACB (American Council of the Blind) Technology Interest Group:** Resources and community for accessible technology.
